# AI Customer Support Workforce

Full multi-agent AI support department — orchestrator, specialists, RAG knowledge,
policy engine, action gateway, approvals, learning, evaluation, simulation, canary,
proactive support, customer health, and observability.

## Quick start

```bash
cd backend
pip install -r requirements.txt
PYTHONPATH=. uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Open http://127.0.0.1:8000

## Tests

```bash
cd backend
PYTHONPATH=. python tests/test_workforce.py
# Expected: 30 passed, 0 failed
```

## Supabase

```bash
# .env
DATABASE_URL=postgresql+asyncpg://postgres.[REF]:[PASSWORD]@aws-0-[REGION].pooler.supabase.com:6543/postgres
```

## Optional credentials

```bash
STRIPE_SECRET_KEY=...
SHOPIFY_SHOP_DOMAIN=...
SHOPIFY_ACCESS_TOKEN=...
SLACK_BOT_TOKEN=...
GMAIL_ACCESS_TOKEN=...
OPENAI_API_KEY=...
```

## Key APIs

| Endpoint | Purpose |
|----------|---------|
| POST /api/v1/auth/signup | Create workspace |
| POST /api/v1/conversations | Start conversation (runs workforce) |
| GET /api/v1/ops/support-manager/report | Daily ops report |
| GET /api/v1/ops/root-cause | Cluster issues |
| POST /api/v1/ops/evaluate | Evaluation harness |
| POST /api/v1/ops/simulate | Persona simulation |
| GET /api/v1/ops/proactive | Proactive opportunities |
| GET /api/v1/ops/feedback | Product feedback intel |
| GET /api/v1/ops/customer-health | Health scores |
| GET /api/v1/ops/versions | AI version / canary |
| GET /api/v1/ops/traces | Observability traces |
| GET /api/v1/ops/events | Event stream |
| GET /api/v1/actions/pending | Approval queue |

See `docs/STATUS.md` for the production-readiness audit and release gates. The feature checklist is not a substitute for the P0/P1 production requirements.
