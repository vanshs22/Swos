# AI Customer Support Workforce — Architecture

## Core Principle

> Agents think. Tools act. Policies constrain. Workflows coordinate.  
> Humans approve exceptions. Data remembers. Evaluations determine whether changes are safe.

## V1 Implemented

### Multi-agent LangGraph Workflow

```
START
  → identify_customer
  → intent_analysis
  → risk_and_route
  → knowledge
  → specialist_resolution
  → qa_and_respond
  → END
```

- Stateful via LangGraph MemorySaver (thread_id = org:conversation)
- Deterministic routing + rule-based fallbacks when no LLM key
- Action proposals go through Tool Gateway with risk/approval gates

### Security & Multi-tenancy

- JWT auth (access + refresh)
- Every entity carries `organization_id`
- Role model: owner / admin / manager / agent / viewer
- Tool Gateway enforces risk levels and approval thresholds
- Prompt-injection defense posture (customer input never overrides system/policy)

### Data Model (Postgres-ready)

Organizations, Users, Customers + CustomerIdentities (entity resolution),  
Conversations, Messages, Tickets, Knowledge*, Policies, Actions + Approvals,  
AgentRuns, AuditLogs

### Tool Gateway

Registered tools with schemas, risk levels, permission requirements,  
idempotency, approval thresholds. Stub handlers for MVP; real connectors  
(Shopify, Stripe, etc.) plug in as adapters.

## Next (V1.1 – V2)

1. Persistent Postgres + RLS
2. Real vector Knowledge Agent (Chroma / pgvector)
3. Specialist agents (Returns, Billing, Order, Technical)
4. Human inbox + approval center UI
5. Policy engine as first-class rules
6. Learning Agent + evaluation harness
7. Canary deployment of agent versions
8. Omnichannel webhooks (Gmail, Twilio, WhatsApp)

## Running Locally

```bash
cd backend
pip install -r requirements.txt
# optional: export OPENAI_API_KEY=sk-...
uvicorn app.main:app --reload --port 8000
```

Open `frontend/public/index.html` in a browser (or serve it) and create a workspace.

API docs: http://127.0.0.1:8000/docs
