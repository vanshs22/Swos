# Production Readiness Audit — 2026-10-03

The original feature checklist overstated readiness. This audit treats executable code and runtime behavior as the source of truth.

## Implemented prototype capabilities
- LangGraph orchestration graph with routing, knowledge, specialist nodes and QA.
- Customer/org data models and application-level organization filters.
- JWT authentication, roles, action approval records.
- Shopify/Stripe/Gmail/Slack connector adapters exist.
- Evaluation/simulation, proactive support, root-cause, feedback and customer-health services exist.
- Basic action policy thresholds and audit-oriented models exist.

## Production blockers

### P0 — must fix before real customers
1. **Durable LangGraph state**: `MemorySaver` is process-local. A restart or second worker can lose graph state. Use a PostgreSQL-backed LangGraph checkpointer and configure it per environment.
2. **Durable knowledge retrieval**: `app/knowledge/vector_store.py` is an in-memory lexical store. Knowledge disappears on restart and is not backed by pgvector/vector DB.
3. **Real tool execution**: the Tool Gateway previously returned successful stub responses for unregistered handlers. It is now hardened to fail closed; real connector-backed handlers still need to be wired.
4. **Durable events/observability**: event bus, traces, idempotency cache and circuit state are process-local. Replace with Postgres/Redis/queue-backed storage before multi-worker deployment.
5. **Durable learning/versioning**: learning proposals and canary versions are process-local. Persist them and gate promotion with evaluation results.
6. **Migrations/RLS**: startup uses `Base.metadata.create_all()`. Production needs versioned Alembic migrations and database-enforced tenant isolation/RLS.
7. **Integration credential vault**: connector credentials are currently environment-based; production multi-tenant connectors need encrypted, tenant-scoped credential storage with rotation/revocation.
8. **Omnichannel webhooks**: the advertised Gmail/Twilio/WhatsApp/social channels do not have complete inbound webhook, signature verification, deduplication and delivery-state implementations.
9. **Background workers**: the queue is in-process. Use a durable queue/worker system and make all jobs retryable/idempotent.
10. **RBAC/policy enforcement**: some administrative endpoints lacked role gates. Role gates were added for approvals and high-impact operations, but action-level permission resolution still needs a tenant policy/permission service.
11. **Security controls**: add rate limiting, CSRF protection where cookie auth is introduced, secret rotation, audit retention, PII redaction, webhook replay protection, request IDs and security headers.
12. **Frontend**: current UI is a single static HTML SPA prototype, not the planned production Next.js/TypeScript application with full inbox, workforce, knowledge, policy, learning, analytics, integration and QA surfaces.

### P1 — required for a serious paid beta
- Real customer graph enrichment from connected systems.
- Provider-specific API idempotency and unknown-outcome reconciliation.
- Human approval concurrency controls / row locking.
- SLA timers and escalation scheduling.
- Attachment/media processing and malware scanning.
- Full agent/skill/policy/version CRUD and audit history.
- Evaluation datasets, regression thresholds and automated canary rollback.
- Usage metering, quotas, billing and plan enforcement.
- Structured metrics/logs/traces exported to an external observability system.
- Backup/restore and disaster-recovery testing.
- Load, concurrency, failover and security testing.

## Hardening applied in this audit
- Production environment validation now requires a stable 32+ character secret, PostgreSQL, non-debug mode, explicit trusted hosts and non-wildcard CORS.
- JWT decoding now enforces token type; refresh tokens have a dedicated refresh endpoint.
- Password creation requires at least 12 characters.
- Approval and high-impact operational endpoints now have role checks.
- Tool Gateway validates required input fields and fails closed instead of reporting a fake successful stub execution.
- Local development defaults to a persistent SQLite file rather than an in-memory database.

## Verification limitation
The environment used for this audit has FastAPI/SQLAlchemy installed but does not have the ZIP's LangGraph/Jose/Passlib/Stripe dependencies, and outbound package installation is unavailable. Therefore the claimed `30 passed` test result could not be reproduced here. Static Python compilation succeeds after the hardening changes.

## Release gate
Do **not** deploy this ZIP as a production customer-facing SaaS yet. It is a hardened prototype / pre-beta foundation. The P0 list above must be closed and verified with integration, security, failure-injection and multi-worker tests before the product should be called production-ready.
