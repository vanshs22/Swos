# AI Support Workforce — Release Gate

## Scope
This build is the latest hardened release candidate. It is designed to fail closed on unsafe production configuration and unconfigured external actions.

## Verified in this environment
- Python compilation across application, tests and migration code: PASS
- Frontend JavaScript syntax check: PASS
- High-risk approval gate: PASS
- Explicit human approval execution: PASS
- Idempotency duplicate execution prevention within gateway: PASS
- Tool timeout handling: implemented
- Tool input primitive validation: implemented
- Production configuration validation: PASS
- Production rejects SQLite: PASS
- Production rejects weak SECRET_KEY/ENCRYPTION_KEY: PASS
- Production rejects enabled API docs: PASS
- Production rejects wildcard CORS: PASS
- HTTP security headers: implemented
- JWT issuer/audience and token type validation: implemented
- PostgreSQL RLS migration: included
- Production startup no longer calls SQLAlchemy `create_all`; migrations are required
- Alembic scaffolding: included
- Frontend dynamic data is HTML-escaped and auth tokens use sessionStorage
- Unconfigured tool adapters fail closed

## Environment limitation
The execution environment does not contain the project's external Python dependencies and cannot download packages. Therefore a full FastAPI/LangGraph/PostgreSQL integration suite cannot truthfully be reported as executed here. The repository includes the complete dependency manifest and release tests for execution in CI.

## Required CI release command
```bash
cd backend
python -m pip install -r requirements.txt
python -m pytest -q
python -m compileall -q app tests migrations
```

## Required production deployment gates
1. Run Alembic against PostgreSQL.
2. Run `migrations/001_production.sql` for pgvector and RLS policies.
3. Configure a durable LangGraph PostgreSQL checkpointer package.
4. Configure encrypted tenant integration credentials.
5. Register real provider adapters before enabling corresponding tools.
6. Run provider sandbox/integration tests for every enabled connector.
7. Configure durable event/job infrastructure for multi-worker deployment.
8. Run external DAST, dependency scanning and secret scanning in CI.
9. Perform a staged canary deployment before enabling autonomous actions.

The application intentionally fails closed rather than pretending those external prerequisites are present.
