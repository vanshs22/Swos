-- PostgreSQL production baseline. Run with a migration runner (Alembic recommended).
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS vector;

-- Tenant isolation: application must SET LOCAL app.organization_id per transaction.
-- These policies are intentionally explicit; service-role migrations should run outside tenant sessions.
ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE actions ENABLE ROW LEVEL SECURITY;
ALTER TABLE action_approvals ENABLE ROW LEVEL SECURITY;
ALTER TABLE knowledge_sources ENABLE ROW LEVEL SECURITY;
ALTER TABLE knowledge_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE knowledge_chunks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS tenant_users ON users;
CREATE POLICY tenant_users ON users USING (organization_id = current_setting('app.organization_id', true));
DROP POLICY IF EXISTS tenant_customers ON customers;
CREATE POLICY tenant_customers ON customers USING (organization_id = current_setting('app.organization_id', true));
DROP POLICY IF EXISTS tenant_conversations ON conversations;
CREATE POLICY tenant_conversations ON conversations USING (organization_id = current_setting('app.organization_id', true));
DROP POLICY IF EXISTS tenant_actions ON actions;
CREATE POLICY tenant_actions ON actions USING (organization_id = current_setting('app.organization_id', true));
DROP POLICY IF EXISTS tenant_action_approvals ON action_approvals;
CREATE POLICY tenant_action_approvals ON action_approvals USING (organization_id = current_setting('app.organization_id', true));
DROP POLICY IF EXISTS tenant_knowledge_sources ON knowledge_sources;
CREATE POLICY tenant_knowledge_sources ON knowledge_sources USING (organization_id = current_setting('app.organization_id', true));
DROP POLICY IF EXISTS tenant_knowledge_documents ON knowledge_documents;
CREATE POLICY tenant_knowledge_documents ON knowledge_documents USING (organization_id = current_setting('app.organization_id', true));
DROP POLICY IF EXISTS tenant_knowledge_chunks ON knowledge_chunks;
CREATE POLICY tenant_knowledge_chunks ON knowledge_chunks USING (organization_id = current_setting('app.organization_id', true));
