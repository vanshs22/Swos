"""Baseline schema generated from SQLAlchemy models.

For an existing deployment, reconcile this migration with the database's current schema
before upgrading. The companion 001_production.sql contains PostgreSQL RLS/vector setup.
"""
from alembic import op
import sqlalchemy as sa

revision = '0001_baseline'
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    from app.db.base import Base
    import app.models  # noqa: F401
    bind = op.get_bind()
    Base.metadata.create_all(bind=bind)

def downgrade():
    pass
