"""Automated tests for AI Support Workforce — no external services required."""
import asyncio
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.services.workforce import process_message
from app.services.policy import evaluate_refund, check_escalation_triggers
from app.knowledge.vector_store import seed_default_policies, search, ingest_document
from app.evaluation.harness import run_evaluation
from app.evaluation.simulation import run_simulation
from app.services.versioning import set_canary, get_active_version, promote_canary, rollback_canary, version_info
from app.services.reliability import with_retry, idempotency_key, circuit_allow, circuit_record
from app.events.bus import publish, recent_events, subscribe
from app.tools.gateway import tool_gateway
from app.core.security import get_password_hash, verify_password, create_access_token, decode_token


def run(coro):
    return asyncio.get_event_loop().run_until_complete(coro)


passed = 0
failed = 0


def check(name, cond, detail=""):
    global passed, failed
    if cond:
        passed += 1
        print(f"  PASS  {name}")
    else:
        failed += 1
        print(f"  FAIL  {name} {detail}")


print("=== Policy Engine ===")
check("auto refund under 50", evaluate_refund(40, 3)[0] == "auto")
check("approval mid amount", evaluate_refund(100, 2)[0] == "requires_approval")
check("human only high", evaluate_refund(2000, 4)[0] == "human_only")
esc, _ = check_escalation_triggers("I will sue with my lawyer", "normal", "normal")
check("legal escalate", esc is True)

print("=== Security ===")
h = get_password_hash("password12345")
check("password hash", verify_password("password12345", h))
check("password reject", not verify_password("wrong", h))
tok = create_access_token("uid", "oid", "owner")
payload = decode_token(tok)
check("jwt decode", payload.sub == "uid" and payload.org == "oid")

print("=== Knowledge RAG ===")
seed_default_policies("test-org")
hits = search("test-org", "refund damaged order")
check("rag returns hits", len(hits) >= 1, str(len(hits)))
check("rag refund policy", any("Refund" in (h.get("title") or "") for h in hits))
n = ingest_document("test-org", "custom1", "Custom FAQ", "Product X works with Device Y fully.")
check("ingest chunks", n >= 1)
hits2 = search("test-org", "Product X Device Y")
check("custom doc searchable", len(hits2) >= 1)

print("=== Workforce turns ===")
out = run(process_message("c1", "test-org", "I want a refund of $30 for order #1001"))
check("intent refund", out.get("intent") == "refund", str(out.get("intent")))
check("has response", bool(out.get("response")))
check("has nodes", len(out.get("node_history") or []) >= 3)
out2 = run(process_message("c2", "test-org", "I will sue you and call my attorney"))
check("legal escalates", out2.get("should_escalate") is True)
out3 = run(process_message("c3", "test-org", "Where is order #2002?"))
check("order intent", out3.get("intent") in ("order_status", "order", "general") or "order" in str(out3.get("intents")))

print("=== Tool Gateway ===")
res = run(tool_gateway.execute("lookup_order", {"order_id": "1"}, "test-org", "ai", autonomy_level=4))
check("lookup executes", res.get("success") is True or res.get("status") in ("succeeded", "requires_approval"))
res2 = run(tool_gateway.execute("create_refund", {"amount": 500}, "test-org", "ai", autonomy_level=2))
check("refund needs approval at low autonomy", res2.get("status") == "requires_approval" or res2.get("success") is False)

print("=== Evaluation harness ===")
ev = run(run_evaluation("eval-org"))
check("eval pass rate 100", ev.get("pass_rate") == 100.0, str(ev))
check("eval all passed", ev.get("passed") == ev.get("total"))

print("=== Simulation ===")
sim = run(run_simulation("sim-org"))
check("simulation personas", sim.get("personas", 0) >= 5)

print("=== Versioning / Canary ===")
set_canary("1.1.0-canary", canary_pct=100)
v = get_active_version("any-conv")
check("canary selected at 100%", v.version == "1.1.0-canary")
promote_canary()
info = version_info()
check("promote works", info["production"]["version"] == "1.1.0-canary")
set_canary("bad", 50)
rollback_canary()
check("rollback clears canary", version_info()["canary"] is None)

print("=== Reliability ===")
async def ok():
    return 42
check("retry success", run(with_retry(ok)) == 42)
k = idempotency_key("a", 1)
check("idempotency key", len(k) == 64)
check("circuit allow initial", circuit_allow("svc1") is True)
for _ in range(5):
    circuit_record("svc1", False)
check("circuit opens", circuit_allow("svc1") is False)

print("=== Events ===")
async def _noop(e):
    pass
subscribe("test.event", _noop)
eid = run(publish("test.event", {"x": 1}, "test-org"))
check("publish event", bool(eid))
check("recent events", len(recent_events("test-org")) >= 1)

print()
print(f"RESULT: {passed} passed, {failed} failed")
sys.exit(0 if failed == 0 else 1)
