import asyncio
from app.tools.gateway import ToolGateway, RiskLevel, ToolDefinition


def test_high_risk_requires_approval_then_executes_after_approval():
    gw = ToolGateway()
    gw.register_handler("refund_test", lambda payload, organization_id, actor_id: asyncio.sleep(0, result={"refund_id":"r1","status":"succeeded"}))
    result = asyncio.run(gw.execute("refund_test", {"amount": 100}, "org1", "actor1", autonomy_level=4))
    assert result["status"] == "failed"  # unknown tool until registered definition exists


def test_human_approval_bypasses_gate_only_after_explicit_approval():
    from app.tools.gateway import TOOL_REGISTRY
    TOOL_REGISTRY["refund_test2"] = ToolDefinition(
        tool_id="refund_test2", name="Refund Test", description="test",
        input_schema={"amount":"number"}, output_schema={"status":"string"},
        risk_level=RiskLevel.HIGH, required_permissions=["billing:refund"]
    )
    gw = ToolGateway()
    async def handler(payload, organization_id, actor_id):
        return {"status":"succeeded"}
    gw.register_handler("refund_test2", handler)
    pending = asyncio.run(gw.execute("refund_test2", {"amount": 100}, "org1", "actor1", autonomy_level=4))
    assert pending["status"] == "requires_approval"
    approved = asyncio.run(gw.execute("refund_test2", {"amount": 100}, "org1", "actor1", autonomy_level=4, human_approved=True))
    assert approved["status"] == "succeeded"
    assert approved["result"]["status"] == "succeeded"
