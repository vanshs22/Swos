"""Shopify Admin API connector — real REST calls when credentials present."""
from __future__ import annotations
from typing import Any, Dict, Optional
import os
import httpx
from app.connectors.base import BaseConnector, ConnectorResult


class ShopifyConnector(BaseConnector):
    name = "shopify"
    category = "commerce"

    def __init__(self, credentials: Dict[str, Any], organization_id: str):
        super().__init__(credentials, organization_id)
        self.shop = credentials.get("shop_domain") or os.getenv("SHOPIFY_SHOP_DOMAIN")
        self.token = credentials.get("access_token") or os.getenv("SHOPIFY_ACCESS_TOKEN")
        self.api_version = credentials.get("api_version", "2024-10")

    def _base(self) -> Optional[str]:
        if not self.shop or not self.token:
            return None
        shop = self.shop.replace("https://", "").replace("http://", "").rstrip("/")
        return f"https://{shop}/admin/api/{self.api_version}"

    def _headers(self) -> Dict[str, str]:
        return {"X-Shopify-Access-Token": self.token or "", "Content-Type": "application/json"}

    async def health_check(self) -> ConnectorResult:
        base = self._base()
        if not base:
            return ConnectorResult(success=False, error="Shopify credentials not configured")
        try:
            async with httpx.AsyncClient(timeout=20) as client:
                r = await client.get(f"{base}/shop.json", headers=self._headers())
                if r.status_code == 200:
                    return ConnectorResult(success=True, data=r.json().get("shop", {}))
                return ConnectorResult(success=False, error=r.text, status_code=r.status_code)
        except Exception as e:
            return ConnectorResult(success=False, error=str(e))

    async def get_order(self, order_id: str) -> ConnectorResult:
        base = self._base()
        if not base:
            return ConnectorResult(success=False, error="Shopify not configured")
        try:
            async with httpx.AsyncClient(timeout=20) as client:
                r = await client.get(f"{base}/orders/{order_id}.json", headers=self._headers())
                if r.status_code == 200:
                    return ConnectorResult(success=True, data=r.json().get("order"))
                return ConnectorResult(success=False, error=r.text, status_code=r.status_code)
        except Exception as e:
            return ConnectorResult(success=False, error=str(e))

    async def search_orders_by_email(self, email: str, limit: int = 5) -> ConnectorResult:
        base = self._base()
        if not base:
            return ConnectorResult(success=False, error="Shopify not configured")
        try:
            async with httpx.AsyncClient(timeout=20) as client:
                r = await client.get(
                    f"{base}/orders.json",
                    headers=self._headers(),
                    params={"email": email, "status": "any", "limit": limit},
                )
                if r.status_code == 200:
                    return ConnectorResult(success=True, data={"orders": r.json().get("orders", [])})
                return ConnectorResult(success=False, error=r.text, status_code=r.status_code)
        except Exception as e:
            return ConnectorResult(success=False, error=str(e))

    async def cancel_order(self, order_id: str, reason: str = "customer") -> ConnectorResult:
        base = self._base()
        if not base:
            return ConnectorResult(success=False, error="Shopify not configured")
        try:
            async with httpx.AsyncClient(timeout=20) as client:
                r = await client.post(
                    f"{base}/orders/{order_id}/cancel.json",
                    headers=self._headers(),
                    json={"reason": reason},
                )
                if r.status_code in (200, 201):
                    return ConnectorResult(success=True, data=r.json().get("order"))
                return ConnectorResult(success=False, error=r.text, status_code=r.status_code)
        except Exception as e:
            return ConnectorResult(success=False, error=str(e))
