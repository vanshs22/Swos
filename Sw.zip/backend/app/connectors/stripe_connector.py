"""Stripe connector — real API calls when STRIPE_SECRET_KEY is configured."""
from __future__ import annotations
from typing import Any, Dict, Optional
import os
from app.connectors.base import BaseConnector, ConnectorResult


class StripeConnector(BaseConnector):
    name = "stripe"
    category = "payments"

    def __init__(self, credentials: Dict[str, Any], organization_id: str):
        super().__init__(credentials, organization_id)
        self.api_key = credentials.get("secret_key") or os.getenv("STRIPE_SECRET_KEY")

    def _client(self):
        if not self.api_key:
            return None
        import stripe
        stripe.api_key = self.api_key
        return stripe

    async def health_check(self) -> ConnectorResult:
        s = self._client()
        if not s:
            return ConnectorResult(success=False, error="Stripe secret key not configured")
        try:
            s.Balance.retrieve()
            return ConnectorResult(success=True, data={"provider": "stripe", "ok": True})
        except Exception as e:
            return ConnectorResult(success=False, error=str(e))

    async def create_refund(
        self,
        payment_intent_id: Optional[str] = None,
        charge_id: Optional[str] = None,
        amount_cents: Optional[int] = None,
        reason: str = "requested_by_customer",
        metadata: Optional[Dict] = None,
    ) -> ConnectorResult:
        s = self._client()
        if not s:
            return ConnectorResult(success=False, error="Stripe not configured")
        try:
            params: Dict[str, Any] = {"reason": reason}
            if payment_intent_id:
                params["payment_intent"] = payment_intent_id
            if charge_id:
                params["charge"] = charge_id
            if amount_cents is not None:
                params["amount"] = int(amount_cents)
            if metadata:
                params["metadata"] = metadata
            ref = s.Refund.create(**params)
            return ConnectorResult(
                success=True,
                data={"refund_id": ref.id, "status": ref.status, "amount": ref.amount},
            )
        except Exception as e:
            return ConnectorResult(success=False, error=str(e))

    async def get_customer(self, customer_id: str) -> ConnectorResult:
        s = self._client()
        if not s:
            return ConnectorResult(success=False, error="Stripe not configured")
        try:
            c = s.Customer.retrieve(customer_id)
            return ConnectorResult(success=True, data={"id": c.id, "email": c.email, "name": c.name})
        except Exception as e:
            return ConnectorResult(success=False, error=str(e))

    async def list_charges(self, customer_id: str, limit: int = 10) -> ConnectorResult:
        s = self._client()
        if not s:
            return ConnectorResult(success=False, error="Stripe not configured")
        try:
            charges = s.Charge.list(customer=customer_id, limit=limit)
            data = [{"id": ch.id, "amount": ch.amount, "status": ch.status, "created": ch.created} for ch in charges.data]
            return ConnectorResult(success=True, data={"charges": data})
        except Exception as e:
            return ConnectorResult(success=False, error=str(e))
