"""Slack connector — incoming webhook + Web API when token present."""
from __future__ import annotations
from typing import Any, Dict, Optional
import os
import httpx
from app.connectors.base import BaseConnector, ConnectorResult


class SlackConnector(BaseConnector):
    name = "slack"
    category = "communication"

    def __init__(self, credentials: Dict[str, Any], organization_id: str):
        super().__init__(credentials, organization_id)
        self.bot_token = credentials.get("bot_token") or os.getenv("SLACK_BOT_TOKEN")
        self.webhook_url = credentials.get("webhook_url") or os.getenv("SLACK_WEBHOOK_URL")

    async def health_check(self) -> ConnectorResult:
        if self.bot_token:
            try:
                async with httpx.AsyncClient(timeout=15) as client:
                    r = await client.post(
                        "https://slack.com/api/auth.test",
                        headers={"Authorization": f"Bearer {self.bot_token}"},
                    )
                    data = r.json()
                    if data.get("ok"):
                        return ConnectorResult(success=True, data=data)
                    return ConnectorResult(success=False, error=data.get("error", "slack error"))
            except Exception as e:
                return ConnectorResult(success=False, error=str(e))
        if self.webhook_url:
            return ConnectorResult(success=True, data={"mode": "webhook"})
        return ConnectorResult(success=False, error="Slack not configured")

    async def post_message(self, text: str, channel: Optional[str] = None) -> ConnectorResult:
        if self.webhook_url:
            try:
                async with httpx.AsyncClient(timeout=15) as client:
                    r = await client.post(self.webhook_url, json={"text": text})
                    if r.status_code == 200:
                        return ConnectorResult(success=True, data={"ok": True})
                    return ConnectorResult(success=False, error=r.text, status_code=r.status_code)
            except Exception as e:
                return ConnectorResult(success=False, error=str(e))
        if self.bot_token and channel:
            try:
                async with httpx.AsyncClient(timeout=15) as client:
                    r = await client.post(
                        "https://slack.com/api/chat.postMessage",
                        headers={"Authorization": f"Bearer {self.bot_token}"},
                        json={"channel": channel, "text": text},
                    )
                    data = r.json()
                    if data.get("ok"):
                        return ConnectorResult(success=True, data=data)
                    return ConnectorResult(success=False, error=data.get("error"))
            except Exception as e:
                return ConnectorResult(success=False, error=str(e))
        return ConnectorResult(success=False, error="Slack not configured")
