"""Gmail connector via Gmail API (OAuth access token) or SMTP fallback patterns."""
from __future__ import annotations
from typing import Any, Dict, Optional
import os
import base64
import httpx
from email.mime.text import MIMEText
from app.connectors.base import BaseConnector, ConnectorResult


class GmailConnector(BaseConnector):
    name = "gmail"
    category = "communication"

    def __init__(self, credentials: Dict[str, Any], organization_id: str):
        super().__init__(credentials, organization_id)
        self.access_token = credentials.get("access_token") or os.getenv("GMAIL_ACCESS_TOKEN")

    async def health_check(self) -> ConnectorResult:
        if not self.access_token:
            return ConnectorResult(success=False, error="Gmail access token not configured")
        try:
            async with httpx.AsyncClient(timeout=15) as client:
                r = await client.get(
                    "https://gmail.googleapis.com/gmail/v1/users/me/profile",
                    headers={"Authorization": f"Bearer {self.access_token}"},
                )
                if r.status_code == 200:
                    return ConnectorResult(success=True, data=r.json())
                return ConnectorResult(success=False, error=r.text, status_code=r.status_code)
        except Exception as e:
            return ConnectorResult(success=False, error=str(e))

    async def send_email(self, to: str, subject: str, body: str, from_email: Optional[str] = None) -> ConnectorResult:
        if not self.access_token:
            return ConnectorResult(success=False, error="Gmail not configured")
        try:
            message = MIMEText(body)
            message["to"] = to
            message["subject"] = subject
            if from_email:
                message["from"] = from_email
            raw = base64.urlsafe_b64encode(message.as_bytes()).decode()
            async with httpx.AsyncClient(timeout=20) as client:
                r = await client.post(
                    "https://gmail.googleapis.com/gmail/v1/users/me/messages/send",
                    headers={"Authorization": f"Bearer {self.access_token}"},
                    json={"raw": raw},
                )
                if r.status_code in (200, 201):
                    return ConnectorResult(success=True, data=r.json())
                return ConnectorResult(success=False, error=r.text, status_code=r.status_code)
        except Exception as e:
            return ConnectorResult(success=False, error=str(e))
