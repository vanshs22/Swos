"""Base connector interface — all external systems implement this."""
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
from dataclasses import dataclass


@dataclass
class ConnectorResult:
    success: bool
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    status_code: Optional[int] = None


class BaseConnector(ABC):
    name: str = "base"
    category: str = "generic"

    def __init__(self, credentials: Dict[str, Any], organization_id: str):
        self.credentials = credentials or {}
        self.organization_id = organization_id

    @abstractmethod
    async def health_check(self) -> ConnectorResult:
        ...
