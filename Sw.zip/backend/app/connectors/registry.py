"""Connector registry — resolve live connectors per org from env or stored credentials."""
from __future__ import annotations
from typing import Any, Dict, Optional, Type
from app.connectors.base import BaseConnector
from app.connectors.stripe_connector import StripeConnector
from app.connectors.shopify_connector import ShopifyConnector
from app.connectors.slack_connector import SlackConnector
from app.connectors.gmail_connector import GmailConnector

CONNECTOR_TYPES: Dict[str, Type[BaseConnector]] = {
    "stripe": StripeConnector,
    "shopify": ShopifyConnector,
    "slack": SlackConnector,
    "gmail": GmailConnector,
}


def get_connector(
    name: str,
    organization_id: str,
    credentials: Optional[Dict[str, Any]] = None,
) -> Optional[BaseConnector]:
    cls = CONNECTOR_TYPES.get(name)
    if not cls:
        return None
    return cls(credentials or {}, organization_id)
