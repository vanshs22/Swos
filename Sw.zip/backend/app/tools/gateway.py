"""
Universal Tool Gateway

Every external action goes through:
AI Agent → Tool Registry → Permission → Tenant → Credential → Rate Limit → Adapter → Provider
Then: Result Validator → Audit

Never let agents call arbitrary APIs directly.
"""

from typing import Dict, Any, Optional, Callable, Awaitable
from dataclasses import dataclass, field
from enum import Enum
import uuid
from datetime import datetime, timezone
import json
import asyncio
import inspect
import math


class RiskLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class ToolDefinition:
    tool_id: str
    name: str
    description: str
    input_schema: Dict[str, Any]
    output_schema: Dict[str, Any]
    risk_level: RiskLevel
    required_permissions: list[str] = field(default_factory=list)
    requires_approval_above: Optional[float] = None  # e.g. refund amount
    idempotent: bool = True
    timeout_seconds: int = 30


# Registry of available tools
TOOL_REGISTRY: Dict[str, ToolDefinition] = {}


def register_tool(tool: ToolDefinition):
    TOOL_REGISTRY[tool.tool_id] = tool


# Core tools (stubs for MVP)
register_tool(ToolDefinition(
    tool_id="lookup_order",
    name="Lookup Order",
    description="Retrieve order details by order ID or email",
    input_schema={"order_id": "string?", "email": "string?"},
    output_schema={"order": "object"},
    risk_level=RiskLevel.LOW,
    required_permissions=["orders:read"],
))

register_tool(ToolDefinition(
    tool_id="create_refund",
    name="Create Refund",
    description="Issue a refund for an order",
    input_schema={"order_id": "string", "amount": "number", "reason": "string"},
    output_schema={"refund_id": "string", "status": "string"},
    risk_level=RiskLevel.HIGH,
    required_permissions=["billing:refund"],
    requires_approval_above=50.0,
    idempotent=True,
))

register_tool(ToolDefinition(
    tool_id="update_customer",
    name="Update Customer",
    description="Update customer profile fields",
    input_schema={"customer_id": "string", "fields": "object"},
    output_schema={"success": "boolean"},
    risk_level=RiskLevel.MEDIUM,
    required_permissions=["customers:write"],
))

register_tool(ToolDefinition(
    tool_id="create_ticket",
    name="Create Ticket",
    description="Create an internal or engineering ticket",
    input_schema={"subject": "string", "description": "string", "priority": "string"},
    output_schema={"ticket_id": "string"},
    risk_level=RiskLevel.LOW,
    required_permissions=["tickets:write"],
))

register_tool(ToolDefinition(
    tool_id="send_message",
    name="Send Message",
    description="Send a message on a channel",
    input_schema={"channel": "string", "to": "string", "content": "string"},
    output_schema={"message_id": "string"},
    risk_level=RiskLevel.LOW,
    required_permissions=["messaging:send"],
))


class ToolGateway:
    """Central execution layer with safety rails."""

    def __init__(self):
        self._handlers: Dict[str, Callable[..., Awaitable[Dict[str, Any]]]] = {}
        self._completed_keys: Dict[str, Dict[str, Any]] = {}

    def register_handler(self, tool_id: str, handler: Callable):
        self._handlers[tool_id] = handler

    async def execute(
        self,
        tool_id: str,
        payload: Dict[str, Any],
        organization_id: str,
        actor_id: str,
        autonomy_level: int = 2,
        idempotency_key: Optional[str] = None,
        human_approved: bool = False,
    ) -> Dict[str, Any]:
        if tool_id not in TOOL_REGISTRY:
            return {"success": False, "error": f"Unknown tool: {tool_id}"}

        tool = TOOL_REGISTRY[tool_id]

        # 1. Input validation. Agent-generated payloads are untrusted.
        required = tool.input_schema or {}
        for key, spec in required.items():
            optional = str(spec).endswith("?")
            if key not in payload and not optional:
                return {"success": False, "status": "failed", "error": f"Missing required field: {key}"}
            if key not in payload:
                continue
            value = payload[key]
            base = str(spec).rstrip("?")
            if base == "string" and not isinstance(value, str):
                return {"success": False, "status": "failed", "error": f"Invalid type for {key}"}
            if base == "number" and (not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(float(value))):
                return {"success": False, "status": "failed", "error": f"Invalid type for {key}"}
            if base == "object" and not isinstance(value, dict):
                return {"success": False, "status": "failed", "error": f"Invalid type for {key}"}
        if tool.idempotent and not idempotency_key:
            return {"success": False, "status": "failed", "error": "Idempotency key required for idempotent tools"}
        if idempotency_key and idempotency_key in self._completed_keys:
            return dict(self._completed_keys[idempotency_key])

        # 2. Authorization is enforced by the API/service caller and tenant-scoped credential resolver.
        # The gateway deliberately does not infer permissions from LLM output.

        # 3. Risk / approval gate
        requires_approval = False
        if tool.risk_level in (RiskLevel.HIGH, RiskLevel.CRITICAL) and not human_approved:
            requires_approval = True
        amount = payload.get("amount")
        if tool.requires_approval_above is not None and amount is not None and float(amount) > tool.requires_approval_above:
            requires_approval = True
        if autonomy_level < 3 and tool.risk_level != RiskLevel.LOW and not human_approved:
            requires_approval = True

        if requires_approval:
            return {
                "success": False,
                "status": "requires_approval",
                "tool_id": tool_id,
                "payload": payload,
                "risk_level": tool.risk_level.value,
                "message": "Action requires human approval before execution",
            }

        # 4. Execute only through a registered real handler
        handler = self._handlers.get(tool_id)
        if handler:
            try:
                result = await asyncio.wait_for(
                    handler(payload, organization_id=organization_id, actor_id=actor_id),
                    timeout=tool.timeout_seconds,
                )
                if not isinstance(result, dict):
                    raise TypeError("Tool adapter must return a JSON object")
                response = {"success": True, "status": "succeeded", "result": result}
                if idempotency_key:
                    self._completed_keys[idempotency_key] = dict(response)
                return response
            except asyncio.TimeoutError:
                return {"success": False, "status": "failed", "error": "Tool execution timed out"}
            except Exception as e:
                return {"success": False, "status": "failed", "error": str(e)}

        return {
            "success": False,
            "status": "failed",
            "error": f"Tool {tool_id} is registered but has no execution adapter configured",
        }


# Global gateway instance
tool_gateway = ToolGateway()
