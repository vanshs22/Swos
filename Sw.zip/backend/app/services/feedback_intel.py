"""Product feedback intelligence from support conversations."""
from __future__ import annotations
from typing import Dict, Any, List
from collections import Counter
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.models.conversation import Message, Conversation

FEEDBACK_KEYWORDS = {
    "pricing": ["expensive", "price", "cost", "pricing", "too much"],
    "ux": ["confusing", "hard to use", "ui", "interface", "can't find"],
    "bug": ["bug", "crash", "error", "broken", "not working"],
    "feature_request": ["wish", "please add", "feature", "would be nice", "missing"],
    "competitor": ["switched from", "competitor", "alternative", "instead of"],
    "docs": ["documentation", "docs unclear", "help article"],
}


async def extract_product_feedback(db: AsyncSession, organization_id: str) -> Dict[str, Any]:
    result = await db.execute(
        select(Message).where(
            Message.organization_id == organization_id,
            Message.role == "customer",
        ).order_by(Message.created_at.desc()).limit(500)
    )
    messages = result.scalars().all()
    categories: Counter = Counter()
    samples: Dict[str, List[str]] = {k: [] for k in FEEDBACK_KEYWORDS}

    for m in messages:
        text = (m.content or "").lower()
        for cat, kws in FEEDBACK_KEYWORDS.items():
            if any(k in text for k in kws):
                categories[cat] += 1
                if len(samples[cat]) < 3:
                    samples[cat].append((m.content or "")[:160])

    return {
        "total_messages_scanned": len(messages),
        "category_counts": dict(categories),
        "samples": {k: v for k, v in samples.items() if v},
        "top_themes": [{"theme": k, "count": v} for k, v in categories.most_common(10)],
    }
