"""Simple async job queue (in-process). Production: Redis/RQ/Celery/Arq."""
from __future__ import annotations
from typing import Any, Callable, Dict, Awaitable, Optional
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
import asyncio
import uuid


class JobStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    RETRYING = "retrying"


@dataclass
class Job:
    id: str
    name: str
    payload: Dict[str, Any]
    status: JobStatus = JobStatus.PENDING
    result: Any = None
    error: Optional[str] = None
    attempts: int = 0
    max_attempts: int = 3
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    finished_at: Optional[str] = None


_jobs: Dict[str, Job] = {}
_handlers: Dict[str, Callable[[Dict[str, Any]], Awaitable[Any]]] = {}
_queue: asyncio.Queue = None  # type: ignore
_worker_started = False


def register_handler(name: str, handler: Callable[[Dict[str, Any]], Awaitable[Any]]) -> None:
    _handlers[name] = handler


async def enqueue(name: str, payload: Dict[str, Any], max_attempts: int = 3) -> str:
    global _queue, _worker_started
    if _queue is None:
        _queue = asyncio.Queue()
    job = Job(id=str(uuid.uuid4()), name=name, payload=payload, max_attempts=max_attempts)
    _jobs[job.id] = job
    await _queue.put(job.id)
    if not _worker_started:
        _worker_started = True
        asyncio.create_task(_worker_loop())
    return job.id


async def _worker_loop() -> None:
    while True:
        job_id = await _queue.get()
        job = _jobs.get(job_id)
        if not job:
            continue
        handler = _handlers.get(job.name)
        job.status = JobStatus.RUNNING
        job.attempts += 1
        try:
            if handler:
                job.result = await handler(job.payload)
            job.status = JobStatus.SUCCEEDED
            job.finished_at = datetime.now(timezone.utc).isoformat()
        except Exception as e:
            job.error = str(e)
            if job.attempts < job.max_attempts:
                job.status = JobStatus.RETRYING
                await asyncio.sleep(min(2 ** job.attempts, 10))
                await _queue.put(job.id)
            else:
                job.status = JobStatus.FAILED
                job.finished_at = datetime.now(timezone.utc).isoformat()


def get_job(job_id: str) -> Optional[Dict[str, Any]]:
    job = _jobs.get(job_id)
    if not job:
        return None
    return {
        "id": job.id,
        "name": job.name,
        "status": job.status.value,
        "attempts": job.attempts,
        "result": job.result,
        "error": job.error,
        "created_at": job.created_at,
        "finished_at": job.finished_at,
    }
