"""
Policy Engine — first-class constraints on every action.

Example rules (stored as JSON on Policy model or defaults):
  refund:
    max_auto: 50
    manager_approval: 250
    human_only: 1000
"""

from typing import Dict, Any, Optional, Tuple


DEFAULT_POLICIES: Dict[str, Dict[str, Any]] = {
    "refund": {
        "max_auto": 50.0,
        "manager_approval_above": 250.0,
        "human_only_above": 1000.0,
        "window_days": 30,
        "require_order_id": True,
    },
    "return": {
        "window_days": 30,
        "restocking_fee_pct": 0,
        "require_condition": True,
    },
    "cancellation": {
        "auto_if_unshipped": True,
        "retention_offer_enabled": True,
    },
    "escalation": {
        "legal_keywords": ["lawsuit", "lawyer", "attorney", "sue", "court"],
        "safety_keywords": ["hurt", "injured", "dangerous", "fire", "toxic"],
        "vip_priority": True,
    },
    "messaging": {
        "max_ai_replies_without_human": 12,
    },
}


def evaluate_refund(
    amount: Optional[float],
    autonomy_level: int,
    is_vip: bool = False,
    policy: Optional[Dict] = None,
) -> Tuple[str, str]:
    """
    Returns (decision, reason)
    decision: auto | requires_approval | human_only | deny
    """
    p = policy or DEFAULT_POLICIES["refund"]
    if amount is None:
        return "requires_approval", "Amount unknown — needs verification"
    if amount <= 0:
        return "deny", "Invalid amount"
    if amount > p.get("human_only_above", 1000):
        return "human_only", f"Amount ${amount} exceeds human-only threshold"
    if amount > p.get("manager_approval_above", 250) or autonomy_level < 3:
        return "requires_approval", f"Amount ${amount} requires approval"
    if amount <= p.get("max_auto", 50) and autonomy_level >= 3:
        return "auto", "Within automatic refund limit"
    return "requires_approval", "Default approval required"


def check_escalation_triggers(
    text: str,
    risk_level: str,
    urgency: str,
    is_vip: bool = False,
) -> Tuple[bool, Optional[str]]:
    text_l = (text or "").lower()
    p = DEFAULT_POLICIES["escalation"]
    for kw in p.get("legal_keywords", []):
        if kw in text_l:
            return True, f"Legal keyword detected: {kw}"
    for kw in p.get("safety_keywords", []):
        if kw in text_l:
            return True, f"Safety keyword detected: {kw}"
    if risk_level in ("legal", "safety", "security"):
        return True, f"Risk category: {risk_level}"
    if urgency == "critical":
        return True, "Critical urgency"
    if is_vip and risk_level == "high":
        return True, "VIP + high risk"
    return False, None
