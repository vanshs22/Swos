"""
Workforce service — runs the LangGraph for a conversation turn.
"""
from typing import Dict, Any, Optional, List
from langchain_core.messages import HumanMessage
from app.agents.graph import workforce_graph
from app.agents.state import WorkforceState
from app.tools.gateway import tool_gateway
from app.services.learning import analyze_trace_for_learning
from app.events.bus import publish
from app.services.observability import start_trace, add_node, complete_trace
from app.services.versioning import get_active_version
import uuid
import hashlib
import json


async def process_message(
    conversation_id: str,
    organization_id: str,
    user_message: str,
    customer_id: Optional[str] = None,
    autonomy_level: int = 2,
    customer_context: Optional[Dict] = None,
) -> Dict[str, Any]:
    thread_id = f"{organization_id}:{conversation_id}"
    version = get_active_version(conversation_id)
    trace_id = start_trace(organization_id, conversation_id)

    initial_state: WorkforceState = {
        "conversation_id": conversation_id,
        "organization_id": organization_id,
        "customer_id": customer_id,
        "messages": [HumanMessage(content=user_message[:8000])],
        "customer_context": customer_context or {},
        "intent": None,
        "intents": [],
        "sentiment": None,
        "urgency": "normal",
        "risk_level": "normal",
        "confidence": 0.0,
        "plan": [],
        "required_specialists": [],
        "investigation_results": {},
        "knowledge_evidence": [],
        "proposed_actions": [],
        "executed_actions": [],
        "should_escalate": False,
        "escalation_reason": None,
        "final_response": None,
        "autonomy_level": autonomy_level,
        "node_history": [],
        "error": None,
    }

    config = {"configurable": {"thread_id": thread_id}}
    await publish("agent.started", {"conversation_id": conversation_id, "version": version.version}, organization_id)

    try:
        final_state = await workforce_graph.ainvoke(initial_state, config=config)
    except Exception as e:
        await publish("agent.failed", {"conversation_id": conversation_id, "error": str(e)}, organization_id)
        complete_trace(organization_id, trace_id, {"error": str(e)})
        return {
            "response": "I'm having trouble processing that right now. A human specialist has been notified.",
            "intent": "error",
            "should_escalate": True,
            "escalation_reason": str(e),
            "error": str(e),
            "node_history": ["error"],
            "proposed_actions": [],
            "executed_actions": [],
            "knowledge_sources": [],
            "transparency": {"why": "System error", "sources_used": [], "specialists": []},
        }

    executed: List[Dict] = []
    pending_approval: List[Dict] = []

    for action in final_state.get("proposed_actions", []):
        requires = action.get("requires_approval", False)
        result = await tool_gateway.execute(
            tool_id=action["tool_name"],
            payload=action.get("input", {}),
            organization_id=organization_id,
            actor_id="ai",
            autonomy_level=autonomy_level,
            idempotency_key=hashlib.sha256((organization_id + ":" + conversation_id + ":" + action["tool_name"] + ":" + json.dumps(action.get("input", {}), sort_keys=True, default=str)).encode()).hexdigest(),
        )
        enriched = {**action, "result": result}
        if result.get("status") == "requires_approval" or requires:
            pending_approval.append(enriched)
            await publish("action.proposed", {"tool": action.get("tool_name"), "status": "requires_approval"}, organization_id)
        else:
            executed.append(enriched)
            await publish("action.executed", {"tool": action.get("tool_name"), "status": result.get("status")}, organization_id)

    try:
        await analyze_trace_for_learning(
            organization_id=organization_id,
            conversation_id=conversation_id,
            intent=final_state.get("intent"),
            confidence=float(final_state.get("confidence") or 0),
            should_escalate=bool(final_state.get("should_escalate")),
            knowledge_sources=final_state.get("knowledge_evidence") or [],
            node_history=final_state.get("node_history") or [],
        )
    except Exception:
        pass

    for node in (final_state.get("node_history") or []):
        add_node(organization_id, trace_id, node)
    complete_trace(organization_id, trace_id, {
        "intent": final_state.get("intent"),
        "escalated": final_state.get("should_escalate"),
        "version": version.version,
    })
    await publish("agent.completed", {
        "conversation_id": conversation_id,
        "intent": final_state.get("intent"),
        "version": version.version,
    }, organization_id)

    return {
        "response": final_state.get("final_response"),
        "intent": final_state.get("intent"),
        "intents": final_state.get("intents"),
        "sentiment": final_state.get("sentiment"),
        "urgency": final_state.get("urgency"),
        "risk_level": final_state.get("risk_level"),
        "confidence": final_state.get("confidence"),
        "should_escalate": final_state.get("should_escalate"),
        "escalation_reason": final_state.get("escalation_reason"),
        "knowledge_sources": final_state.get("knowledge_evidence"),
        "proposed_actions": final_state.get("proposed_actions"),
        "executed_actions": executed,
        "pending_approval_actions": pending_approval,
        "node_history": final_state.get("node_history"),
        "version": version.version,
        "transparency": {
            "why": f"Detected intent '{final_state.get('intent')}' with confidence {final_state.get('confidence')}",
            "sources_used": [e.get("source") or e.get("title") for e in final_state.get("knowledge_evidence", [])],
            "specialists": final_state.get("required_specialists"),
            "nodes": final_state.get("node_history"),
            "version": version.version,
        },
    }
