"""
Learning Agent (safe self-improvement loop).

Traces → classify gap → proposal → evaluate → human approval → version → canary.

We never let the AI rewrite its own system prompt automatically.
"""

from typing import Dict, Any, List, Optional
from datetime import datetime, timezone
import uuid


class LearningProposal:
    def __init__(
        self,
        category: str,  # knowledge_gap | procedure_gap | tool_issue | prompt_issue
        title: str,
        evidence: List[Dict],
        draft: str,
        estimated_impact: str,
        organization_id: str,
    ):
        self.id = str(uuid.uuid4())
        self.category = category
        self.title = title
        self.evidence = evidence
        self.draft = draft
        self.estimated_impact = estimated_impact
        self.organization_id = organization_id
        self.status = "proposed"  # proposed | evaluating | approved | rejected | canary | production
        self.created_at = datetime.now(timezone.utc)


# In-memory store for demo (production → DB table learning_proposals)
_proposals: Dict[str, List[LearningProposal]] = {}


async def analyze_trace_for_learning(
    organization_id: str,
    conversation_id: str,
    intent: Optional[str],
    confidence: float,
    should_escalate: bool,
    knowledge_sources: List[Dict],
    node_history: List[str],
) -> Optional[LearningProposal]:
    """
    Lightweight heuristic learning detector.
    Real version would aggregate across many conversations.
    """
    # Example: low confidence + no strong knowledge → knowledge gap
    if confidence < 0.5 and (not knowledge_sources or knowledge_sources[0].get("category") == "general"):
        proposal = LearningProposal(
            category="knowledge_gap",
            title=f"Possible knowledge gap around intent '{intent or 'unknown'}'",
            evidence=[{
                "conversation_id": conversation_id,
                "confidence": confidence,
                "sources": knowledge_sources,
            }],
            draft=f"Consider adding or improving a help article for: {intent}",
            estimated_impact="Reduce future escalations / low-confidence replies",
            organization_id=organization_id,
        )
        _proposals.setdefault(organization_id, []).append(proposal)
        return proposal
    return None


def list_proposals(organization_id: str) -> List[Dict[str, Any]]:
    return [
        {
            "id": p.id,
            "category": p.category,
            "title": p.title,
            "draft": p.draft,
            "estimated_impact": p.estimated_impact,
            "status": p.status,
            "created_at": p.created_at.isoformat(),
        }
        for p in _proposals.get(organization_id, [])
    ]
