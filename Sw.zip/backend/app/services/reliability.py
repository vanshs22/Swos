"""Reliability helpers: retry, circuit breaker, idempotency, timeouts."""
from __future__ import annotations
from typing import Any, Callable, Awaitable, TypeVar, Optional
from datetime import datetime, timezone, timedelta
from collections import defaultdict
import asyncio
import hashlib
import json

T = TypeVar("T")

_idempotency_cache: Dict[str, Any] = {}
_circuit: Dict[str, Dict[str, Any]] = defaultdict(lambda: {"failures": 0, "open_until": None})


async def with_retry(
    fn: Callable[[], Awaitable[T]],
    retries: int = 3,
    base_delay: float = 0.5,
    exceptions: tuple = (Exception,),
) -> T:
    last: Exception | None = None
    for attempt in range(retries + 1):
        try:
            return await fn()
        except exceptions as e:
            last = e
            if attempt >= retries:
                break
            await asyncio.sleep(base_delay * (2 ** attempt))
    assert last is not None
    raise last


async def with_timeout(fn: Callable[[], Awaitable[T]], seconds: float = 30) -> T:
    return await asyncio.wait_for(fn(), timeout=seconds)


def circuit_allow(name: str, failure_threshold: int = 5, cool_down_sec: int = 60) -> bool:
    state = _circuit[name]
    until = state.get("open_until")
    if until and datetime.now(timezone.utc) < until:
        return False
    if until and datetime.now(timezone.utc) >= until:
        state["failures"] = 0
        state["open_until"] = None
    return True


def circuit_record(name: str, success: bool, failure_threshold: int = 5, cool_down_sec: int = 60) -> None:
    state = _circuit[name]
    if success:
        state["failures"] = 0
        state["open_until"] = None
    else:
        state["failures"] = int(state.get("failures") or 0) + 1
        if state["failures"] >= failure_threshold:
            state["open_until"] = datetime.now(timezone.utc) + timedelta(seconds=cool_down_sec)


def idempotency_key(*parts: Any) -> str:
    raw = json.dumps(parts, sort_keys=True, default=str)
    return hashlib.sha256(raw.encode()).hexdigest()


def idempotent_get(key: str) -> Optional[Any]:
    return _idempotency_cache.get(key)


def idempotent_set(key: str, value: Any) -> None:
    _idempotency_cache[key] = value
    # bound size
    if len(_idempotency_cache) > 5000:
        for k in list(_idempotency_cache.keys())[:1000]:
            _idempotency_cache.pop(k, None)
