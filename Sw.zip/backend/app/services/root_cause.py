"""Root Cause Agent — cluster similar issues from conversation signals."""
from __future__ import annotations
from typing import Dict, Any, List
from collections import Counter
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.models.conversation import Conversation, Message


async def detect_root_causes(db: AsyncSession, organization_id: str, min_cluster: int = 3) -> Dict[str, Any]:
    result = await db.execute(
        select(Conversation).where(Conversation.organization_id == organization_id).limit(500)
    )
    convs = result.scalars().all()
    intent_counts = Counter(c.current_intent for c in convs if c.current_intent)
    risk_counts = Counter(c.risk_level for c in convs if c.risk_level)

    # Sample recent message text for keyword clusters
    msg_q = await db.execute(
        select(Message).where(
            Message.organization_id == organization_id,
            Message.role == "customer",
        ).order_by(Message.created_at.desc()).limit(200)
    )
    messages = msg_q.scalars().all()
    keywords = Counter()
    interest = ["checkout", "login", "password", "shipping", "refund", "cancel", "bug", "error", "payment", "crash"]
    for m in messages:
        low = (m.content or "").lower()
        for kw in interest:
            if kw in low:
                keywords[kw] += 1

    clusters = []
    for intent, count in intent_counts.most_common(10):
        if count >= min_cluster:
            clusters.append({
                "type": "intent_cluster",
                "signal": intent,
                "count": count,
                "suggestion": f"Review knowledge/procedure for '{intent}' — {count} conversations",
            })
    for kw, count in keywords.most_common(10):
        if count >= min_cluster:
            clusters.append({
                "type": "keyword_cluster",
                "signal": kw,
                "count": count,
                "suggestion": f"Emerging issue keyword '{kw}' appeared {count} times — consider FAQ or incident",
            })

    return {
        "clusters": clusters,
        "intent_distribution": dict(intent_counts),
        "risk_distribution": dict(risk_counts),
        "message_sample_size": len(messages),
    }
