"""Customer identity resolution across systems."""
from __future__ import annotations
from typing import Optional, List, Dict, Any
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.models.customer import Customer, CustomerIdentity


async def resolve_customer(
    db: AsyncSession,
    organization_id: str,
    email: Optional[str] = None,
    phone: Optional[str] = None,
    external_provider: Optional[str] = None,
    external_id: Optional[str] = None,
    full_name: Optional[str] = None,
) -> Customer:
    """Find or create canonical customer and link identities."""
    customer: Optional[Customer] = None

    if external_provider and external_id:
        r = await db.execute(
            select(CustomerIdentity).where(
                CustomerIdentity.organization_id == organization_id,
                CustomerIdentity.provider == external_provider,
                CustomerIdentity.external_id == external_id,
            )
        )
        ident = r.scalar_one_or_none()
        if ident:
            r2 = await db.execute(select(Customer).where(Customer.id == ident.customer_id))
            customer = r2.scalar_one_or_none()

    if not customer and email:
        r = await db.execute(
            select(Customer).where(
                Customer.organization_id == organization_id,
                Customer.email == email,
            )
        )
        customer = r.scalar_one_or_none()

    if not customer and phone:
        r = await db.execute(
            select(Customer).where(
                Customer.organization_id == organization_id,
                Customer.phone == phone,
            )
        )
        customer = r.scalar_one_or_none()

    if not customer:
        customer = Customer(
            organization_id=organization_id,
            email=email,
            phone=phone,
            full_name=full_name,
        )
        db.add(customer)
        await db.flush()

    # Link identity if provided
    if external_provider and external_id:
        r = await db.execute(
            select(CustomerIdentity).where(
                CustomerIdentity.organization_id == organization_id,
                CustomerIdentity.provider == external_provider,
                CustomerIdentity.external_id == external_id,
            )
        )
        if not r.scalar_one_or_none():
            db.add(CustomerIdentity(
                customer_id=customer.id,
                organization_id=organization_id,
                provider=external_provider,
                external_id=external_id,
            ))
            await db.flush()

    # Also link email as identity
    if email:
        r = await db.execute(
            select(CustomerIdentity).where(
                CustomerIdentity.organization_id == organization_id,
                CustomerIdentity.provider == "email",
                CustomerIdentity.external_id == email,
            )
        )
        if not r.scalar_one_or_none():
            db.add(CustomerIdentity(
                customer_id=customer.id,
                organization_id=organization_id,
                provider="email",
                external_id=email,
            ))
            await db.flush()

    return customer


async def build_customer_context(db: AsyncSession, customer: Customer) -> Dict[str, Any]:
    r = await db.execute(
        select(CustomerIdentity).where(CustomerIdentity.customer_id == customer.id)
    )
    identities = [
        {"provider": i.provider, "external_id": i.external_id}
        for i in r.scalars().all()
    ]
    return {
        "customer": {
            "id": customer.id,
            "email": customer.email,
            "phone": customer.phone,
            "full_name": customer.full_name,
            "vip": customer.vip,
            "status": customer.status,
            "lifetime_value": customer.lifetime_value,
        },
        "identities": identities,
        "history": [],
        "orders": [],
        "payments": [],
        "preferences": customer.preferences or {},
        "risk": "normal",
        "value": "vip" if customer.vip else "standard",
    }
