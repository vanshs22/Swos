"""AI versioning + simple canary routing."""
from __future__ import annotations
from typing import Dict, Any, Optional
from dataclasses import dataclass, field
from datetime import datetime, timezone
import hashlib

@dataclass
class AgentVersion:
    version: str
    prompt_version: str = "1"
    policy_version: str = "1"
    knowledge_version: str = "1"
    canary_pct: int = 0  # 0-100
    active: bool = True
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    metrics: Dict[str, float] = field(default_factory=dict)

_CURRENT = AgentVersion(version="1.0.0", canary_pct=0)
_CANARY: Optional[AgentVersion] = None


def get_active_version(conversation_id: str | None = None) -> AgentVersion:
    """Route a fraction of traffic to canary based on conversation id hash."""
    global _CANARY
    if _CANARY and _CANARY.active and _CANARY.canary_pct > 0 and conversation_id:
        h = int(hashlib.md5(conversation_id.encode()).hexdigest(), 16) % 100
        if h < _CANARY.canary_pct:
            return _CANARY
    return _CURRENT


def set_production_version(version: str, **kwargs) -> AgentVersion:
    global _CURRENT
    _CURRENT = AgentVersion(version=version, **kwargs)
    return _CURRENT


def set_canary(version: str, canary_pct: int = 5, **kwargs) -> AgentVersion:
    global _CANARY
    _CANARY = AgentVersion(version=version, canary_pct=canary_pct, **kwargs)
    return _CANARY


def promote_canary() -> Optional[AgentVersion]:
    global _CURRENT, _CANARY
    if not _CANARY:
        return None
    _CURRENT = AgentVersion(
        version=_CANARY.version,
        prompt_version=_CANARY.prompt_version,
        policy_version=_CANARY.policy_version,
        knowledge_version=_CANARY.knowledge_version,
        canary_pct=0,
        active=True,
    )
    _CANARY = None
    return _CURRENT


def rollback_canary() -> None:
    global _CANARY
    _CANARY = None


def version_info() -> Dict[str, Any]:
    return {
        "production": {
            "version": _CURRENT.version,
            "prompt_version": _CURRENT.prompt_version,
            "policy_version": _CURRENT.policy_version,
            "knowledge_version": _CURRENT.knowledge_version,
        },
        "canary": None if not _CANARY else {
            "version": _CANARY.version,
            "canary_pct": _CANARY.canary_pct,
        },
    }
