"""Customer health scoring."""
from __future__ import annotations
from typing import Dict, Any, List
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from app.models.customer import Customer
from app.models.conversation import Conversation


async def score_customer(db: AsyncSession, organization_id: str, customer_id: str) -> Dict[str, Any]:
    r = await db.execute(
        select(Customer).where(Customer.id == customer_id, Customer.organization_id == organization_id)
    )
    customer = r.scalar_one_or_none()
    if not customer:
        return {"error": "not_found"}

    conv_q = await db.execute(
        select(Conversation).where(
            Conversation.organization_id == organization_id,
            Conversation.customer_id == customer_id,
        )
    )
    convs = conv_q.scalars().all()
    escalated = sum(1 for c in convs if c.status == "escalated")
    open_c = sum(1 for c in convs if c.status in ("open", "pending"))
    negative = sum(1 for c in convs if (c.sentiment or "") in ("negative", "angry"))

    score = 100
    score -= escalated * 15
    score -= open_c * 5
    score -= negative * 10
    if customer.vip:
        score += 5
    score = max(0, min(100, score))

    if score >= 80:
        band = "healthy"
    elif score >= 60:
        band = "at_risk"
    elif score >= 40:
        band = "high_risk"
    else:
        band = "critical"

    return {
        "customer_id": customer_id,
        "email": customer.email,
        "vip": customer.vip,
        "score": score,
        "band": band,
        "signals": {
            "conversations": len(convs),
            "escalated": escalated,
            "open": open_c,
            "negative_sentiment": negative,
        },
    }


async def list_health(db: AsyncSession, organization_id: str, limit: int = 50) -> List[Dict[str, Any]]:
    r = await db.execute(
        select(Customer).where(Customer.organization_id == organization_id).limit(limit)
    )
    out = []
    for c in r.scalars().all():
        out.append(await score_customer(db, organization_id, c.id))
    out.sort(key=lambda x: x.get("score", 100))
    return out
