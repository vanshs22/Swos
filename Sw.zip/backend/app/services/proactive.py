"""Proactive support — detect conditions that warrant outbound outreach."""
from __future__ import annotations
from typing import List, Dict, Any
from datetime import datetime, timezone, timedelta
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.models.customer import Customer
from app.models.conversation import Conversation


async def detect_proactive_opportunities(
    db: AsyncSession,
    organization_id: str,
) -> List[Dict[str, Any]]:
    """Heuristic proactive triggers from existing data."""
    opportunities: List[Dict[str, Any]] = []

    # Customers with many recent escalations / open issues
    result = await db.execute(
        select(Conversation).where(
            Conversation.organization_id == organization_id,
            Conversation.status.in_(["escalated", "open"]),
        ).limit(200)
    )
    convs = result.scalars().all()
    by_customer: Dict[str, int] = {}
    for c in convs:
        if c.customer_id:
            by_customer[c.customer_id] = by_customer.get(c.customer_id, 0) + 1

    for cid, count in by_customer.items():
        if count >= 2:
            opportunities.append({
                "type": "repeat_issues",
                "customer_id": cid,
                "signal": f"{count} open/escalated conversations",
                "suggested_message": "We noticed you've had multiple recent issues — a specialist can help resolve this fully.",
                "priority": "high" if count >= 3 else "normal",
            })

    # VIP customers with any open ticket
    vip_q = await db.execute(
        select(Customer).where(
            Customer.organization_id == organization_id,
            Customer.vip == True,
        )
    )
    for vip in vip_q.scalars().all():
        open_c = by_customer.get(vip.id, 0)
        if open_c > 0:
            opportunities.append({
                "type": "vip_attention",
                "customer_id": vip.id,
                "signal": "VIP with open conversation",
                "suggested_message": f"Hi {vip.full_name or 'there'}, we're prioritizing your request and will update you shortly.",
                "priority": "high",
            })

    return opportunities
