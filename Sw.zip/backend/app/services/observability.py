"""Structured observability traces for agent runs."""
from __future__ import annotations
from typing import Dict, Any, List, Optional
from datetime import datetime, timezone
from collections import defaultdict
import uuid

_traces: Dict[str, List[Dict[str, Any]]] = defaultdict(list)


def start_trace(
    organization_id: str,
    conversation_id: str,
    graph_id: str = "main_workforce",
) -> str:
    trace_id = str(uuid.uuid4())
    _traces[organization_id].append({
        "trace_id": trace_id,
        "conversation_id": conversation_id,
        "graph_id": graph_id,
        "started_at": datetime.now(timezone.utc).isoformat(),
        "nodes": [],
        "tools": [],
        "status": "running",
    })
    return trace_id


def add_node(organization_id: str, trace_id: str, node: str, meta: Optional[Dict] = None) -> None:
    for t in _traces.get(organization_id, []):
        if t["trace_id"] == trace_id:
            t["nodes"].append({"node": node, "meta": meta or {}, "ts": datetime.now(timezone.utc).isoformat()})
            break


def complete_trace(organization_id: str, trace_id: str, outcome: Dict[str, Any]) -> None:
    for t in _traces.get(organization_id, []):
        if t["trace_id"] == trace_id:
            t["status"] = "completed"
            t["outcome"] = outcome
            t["completed_at"] = datetime.now(timezone.utc).isoformat()
            break


def list_traces(organization_id: str, limit: int = 50) -> List[Dict[str, Any]]:
    return list(reversed(_traces.get(organization_id, [])[-limit:]))
