"""Support Manager Agent — operational report over workforce data."""
from __future__ import annotations
from typing import Dict, Any
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from app.models.conversation import Conversation
from app.models.action import Action
from app.models.customer import Customer
from app.services.learning import list_proposals


async def generate_daily_report(db: AsyncSession, organization_id: str) -> Dict[str, Any]:
    total = (await db.execute(
        select(func.count()).select_from(Conversation).where(Conversation.organization_id == organization_id)
    )).scalar() or 0
    open_c = (await db.execute(
        select(func.count()).select_from(Conversation).where(
            Conversation.organization_id == organization_id,
            Conversation.status.in_(["open", "pending"]),
        )
    )).scalar() or 0
    escalated = (await db.execute(
        select(func.count()).select_from(Conversation).where(
            Conversation.organization_id == organization_id,
            Conversation.status == "escalated",
        )
    )).scalar() or 0
    resolved = (await db.execute(
        select(func.count()).select_from(Conversation).where(
            Conversation.organization_id == organization_id,
            Conversation.status.in_(["resolved", "closed"]),
        )
    )).scalar() or 0
    pending_actions = (await db.execute(
        select(func.count()).select_from(Action).where(
            Action.organization_id == organization_id,
            Action.status.in_(["proposed", "requires_approval"]),
        )
    )).scalar() or 0
    customers = (await db.execute(
        select(func.count()).select_from(Customer).where(Customer.organization_id == organization_id)
    )).scalar() or 0

    # Top intents
    intents_q = await db.execute(
        select(Conversation.current_intent, func.count())
        .where(Conversation.organization_id == organization_id, Conversation.current_intent.isnot(None))
        .group_by(Conversation.current_intent)
        .order_by(func.count().desc())
        .limit(5)
    )
    top_intents = [{"intent": row[0], "count": row[1]} for row in intents_q.all()]

    proposals = list_proposals(organization_id)
    resolution_rate = round((resolved / total) * 100, 1) if total else 0.0

    recommendations = []
    if pending_actions > 0:
        recommendations.append(f"Review {pending_actions} pending action approval(s).")
    if escalated > 0:
        recommendations.append(f"Handle {escalated} escalated conversation(s).")
    if proposals:
        recommendations.append(f"Review {len(proposals)} learning proposal(s).")
    if not recommendations:
        recommendations.append("No critical attention items.")

    top_str = ', '.join(str(i.get('intent')) + '(' + str(i.get('count')) + ')' for i in top_intents) or 'n/a'
    return {
        "report_type": "support_workforce_daily",
        "workload": {
            "total_conversations": total,
            "open": open_c,
            "resolved": resolved,
            "escalated": escalated,
            "resolution_rate_pct": resolution_rate,
        },
        "attention": {
            "pending_approvals": pending_actions,
            "open_escalations": escalated,
        },
        "top_intents": top_intents,
        "customers": customers,
        "learning_proposals": len(proposals),
        "recommendations": recommendations,
        "narrative": (
            f"SUPPORT WORKFORCE REPORT\n"
            f"{total} conversations · AI/open mix tracked · Resolved: {resolved} ({resolution_rate}%)\n"
            f"Escalated: {escalated} · Pending approvals: {pending_actions}\n"
            f"Top intents: {', '.join(str(i.get('intent')) + '(' + str(i.get('count')) + ')' for i in top_intents) or 'n/a'}\n"
            f"Recommended: {'; '.join(recommendations)}"
        ),
    }
