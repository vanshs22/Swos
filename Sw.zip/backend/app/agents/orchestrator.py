"""
Workforce Orchestrator nodes — production-oriented with policy integration.
"""

from typing import Dict, Any, List
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI
from app.core.config import settings
from app.agents.state import WorkforceState
from app.services.policy import evaluate_refund, check_escalation_triggers, DEFAULT_POLICIES
import json
import re


def get_llm(temperature: float = 0.1):
    if not settings.OPENAI_API_KEY:
        return None
    return ChatOpenAI(
        model=settings.DEFAULT_MODEL,
        temperature=temperature,
        api_key=settings.OPENAI_API_KEY,
    )


def _last_human(messages) -> str:
    for m in reversed(messages or []):
        if isinstance(m, HumanMessage) or getattr(m, "type", None) == "human":
            return m.content or ""
    return ""


async def identify_customer_node(state: WorkforceState) -> Dict[str, Any]:
    ctx = state.get("customer_context") or {}
    if not ctx.get("customer"):
        ctx = {
            "customer": {
                "id": state.get("customer_id"),
                "vip": False,
                "lifetime_value": 0,
            },
            "history": [],
            "orders": [],
            "payments": [],
            "preferences": {},
            "risk": "normal",
            "value": "standard",
        }
    return {
        "customer_context": ctx,
        "node_history": state.get("node_history", []) + ["identify_customer"],
    }


async def intent_analysis_node(state: WorkforceState) -> Dict[str, Any]:
    last_user_msg = _last_human(state.get("messages"))
    llm = get_llm()

    if llm is None:
        text = last_user_msg.lower()
        intent = "general"
        urgency = "normal"
        sentiment = "neutral"
        risk = "normal"
        intents = []

        rules = [
            (["refund", "money back", "reimburse"], "refund"),
            (["return", "send back", "exchange"], "return"),
            (["order", "tracking", "shipped", "delivery", "where is my"], "order_status"),
            (["cancel", "cancellation", "stop subscription"], "cancellation"),
            (["password", "login", "can't access", "reset"], "technical"),
            (["bill", "invoice", "charged", "payment", "card"], "billing"),
            (["appointment", "schedule", "book", "reschedule"], "appointment"),
            (["angry", "terrible", "worst", "hate", "frustrated"], None),  # sentiment
        ]
        for kws, val in rules:
            if any(w in text for w in kws):
                if val:
                    intents.append(val)
                else:
                    sentiment = "negative"
                    urgency = "high"

        if not intents:
            intents = ["general"]
        intent = intents[0]

        # Risk signals
        if any(w in text for w in ["lawsuit", "lawyer", "attorney", "sue"]):
            risk = "legal"
            urgency = "urgent"
        elif any(w in text for w in ["hack", "stolen", "unauthorized", "fraud"]):
            risk = "security"
            urgency = "high"

        return {
            "intent": intent,
            "intents": intents,
            "sentiment": sentiment,
            "urgency": urgency,
            "risk_level": risk,
            "confidence": 0.78,
            "node_history": state.get("node_history", []) + ["intent_analysis"],
        }

    system = """You are an Intent & Triage specialist for a professional customer support workforce.
Return STRICT JSON only (no markdown):
{
  "intent": "primary_intent",
  "intents": ["list"],
  "sentiment": "positive|neutral|negative|angry",
  "urgency": "low|normal|high|urgent|critical",
  "risk_level": "normal|financial|privacy|security|legal|safety",
  "confidence": 0.0-1.0
}
Allowed intents: order_status, refund, return, cancellation, billing, technical, account, shipping, product, complaint, sales, appointment, subscription, bug, feature_request, security, fraud, vip, general
"""
    try:
        response = await llm.ainvoke([
            SystemMessage(content=system),
            HumanMessage(content=last_user_msg[:3000]),
        ])
        content = response.content.strip()
        if content.startswith("```"):
            content = re.sub(r"^```(?:json)?\n?", "", content)
            content = re.sub(r"\n?```$", "", content)
        data = json.loads(content)
    except Exception:
        data = {
            "intent": "general",
            "intents": ["general"],
            "sentiment": "neutral",
            "urgency": "normal",
            "risk_level": "normal",
            "confidence": 0.5,
        }

    return {
        "intent": data.get("intent", "general"),
        "intents": data.get("intents") or [data.get("intent", "general")],
        "sentiment": data.get("sentiment", "neutral"),
        "urgency": data.get("urgency", "normal"),
        "risk_level": data.get("risk_level", "normal"),
        "confidence": float(data.get("confidence", 0.5)),
        "node_history": state.get("node_history", []) + ["intent_analysis"],
    }


async def risk_and_route_node(state: WorkforceState) -> Dict[str, Any]:
    intent = state.get("intent", "general")
    risk = state.get("risk_level", "normal")
    urgency = state.get("urgency", "normal")
    customer = state.get("customer_context", {}).get("customer", {})
    last_msg = _last_human(state.get("messages"))

    routing = {
        "refund": ["returns", "billing", "knowledge"],
        "return": ["returns", "order", "knowledge"],
        "order_status": ["order", "knowledge"],
        "cancellation": ["billing", "retention", "knowledge"],
        "billing": ["billing", "knowledge"],
        "technical": ["technical", "knowledge"],
        "complaint": ["complaint", "knowledge"],
        "sales": ["sales", "knowledge"],
        "appointment": ["scheduling", "knowledge"],
        "general": ["knowledge"],
    }
    specialists = routing.get(intent, ["knowledge"])

    should_escalate, reason = check_escalation_triggers(
        last_msg, risk, urgency, is_vip=bool(customer.get("vip"))
    )

    return {
        "required_specialists": specialists,
        "should_escalate": should_escalate,
        "escalation_reason": reason,
        "node_history": state.get("node_history", []) + ["risk_and_route"],
    }


async def knowledge_node(state: WorkforceState) -> Dict[str, Any]:
    """Retrieve evidence from vector knowledge store + fallback demo policies."""
    intent = state.get("intent", "general")
    msgs = state.get("messages") or []
    query = intent
    for m in reversed(msgs):
        c = getattr(m, "content", None)
        if c:
            query = c[:500]
            break
    org_id = state.get("organization_id") or "default"
    evidence = []
    try:
        from app.knowledge.vector_store import search, seed_default_policies
        seed_default_policies(org_id)
        hits = search(org_id, query, n_results=4)
        for h in hits:
            evidence.append({
                "title": h.get("title") or "Knowledge",
                "content": h.get("content"),
                "source": h.get("source") or "vector",
                "category": h.get("category"),
                "score": h.get("score"),
            })
    except Exception:
        evidence = []
    if not evidence:
        # minimal fallback
        evidence = [{
            "title": "General Support",
            "content": "We are here to help. Please provide your order number or account email for faster assistance.",
            "source": "System",
            "category": "general",
        }]
    return {
        "knowledge_evidence": evidence,
        "node_history": state.get("node_history", []) + ["knowledge"],
    }



async def specialist_resolution_node(state: WorkforceState) -> Dict[str, Any]:
    intent = state.get("intent", "general")
    evidence = state.get("knowledge_evidence", [])
    customer = state.get("customer_context", {}).get("customer", {})
    last_user = _last_human(state.get("messages"))
    autonomy = state.get("autonomy_level", 2)

    proposed_actions: List[Dict] = []
    response_text = ""

    policy_snip = evidence[0]["content"] if evidence else ""

    if intent == "refund":
        # Extract possible amount/order with simple patterns
        # Prefer explicit $ amounts; avoid treating order numbers as money
        amount_match = re.search(r"\$\s*(\d+(?:\.\d{1,2})?)", last_user)
        amount = float(amount_match.group(1)) if amount_match else None
        order_match = re.search(r"(?:order\s*#?\s*|#)(\d{4,})", last_user, re.I)
        order_id = order_match.group(1) if order_match else None

        decision, reason = evaluate_refund(amount, autonomy, is_vip=bool(customer.get("vip")))
        requires_approval = decision in ("requires_approval", "human_only")

        proposed_actions.append({
            "tool_name": "create_refund",
            "action_type": "refund",
            "input": {
                "amount": amount,
                "reason": "customer_request",
                "order_id": order_id,
            },
            "risk_level": "high" if (amount or 0) > 250 else "medium",
            "requires_approval": requires_approval,
            "policy_decision": decision,
            "policy_reason": reason,
        })

        if order_id:
            response_text = (
                f"I've located a reference to order #{order_id}. "
                f"According to our policy: {policy_snip}\n\n"
            )
            if decision == "auto":
                response_text += "This looks eligible for automatic processing. I'll prepare the refund now."
            else:
                response_text += (
                    "I need to verify eligibility (condition, timeframe, amount). "
                    "Please confirm the order number and whether the item is unused/defective, "
                    "and share a photo if damaged. A specialist will finalize if approval is required."
                )
        else:
            response_text = (
                f"I understand you'd like a refund. {policy_snip}\n\n"
                "Please share your order number so I can check eligibility and next steps."
            )

    elif intent == "order_status":
        order_match = re.search(r"(?:order\s*#?\s*|#)(\d{4,})", last_user, re.I)
        order_id = order_match.group(1) if order_match else None
        if order_id:
            proposed_actions.append({
                "tool_name": "lookup_order",
                "action_type": "order_lookup",
                "input": {"order_id": order_id},
                "risk_level": "low",
                "requires_approval": False,
            })
            response_text = (
                f"Checking order #{order_id} now. "
                "Standard delivery is 3–5 business days. I'll share the latest status as soon as I have it."
            )
        else:
            response_text = (
                "I'd be happy to check your order. Please provide the order number "
                "(usually starts with #) or the email used at checkout."
            )

    elif intent == "cancellation":
        response_text = (
            f"{policy_snip}\n\n"
            "If the order hasn't shipped I can usually cancel it immediately. "
            "Please share the order number. If this is a subscription, I can also check retention options."
        )
        proposed_actions.append({
            "tool_name": "create_ticket",
            "action_type": "cancellation_request",
            "input": {"subject": "Cancellation request", "priority": "normal"},
            "risk_level": "medium",
            "requires_approval": True,
        })

    elif intent == "technical":
        response_text = (
            f"{policy_snip}\n\n"
            "Could you tell me: (1) what you were trying to do, (2) the exact error message, "
            "and (3) device/browser? That lets me diagnose faster."
        )

    else:
        llm = get_llm(temperature=0.3)
        if llm and evidence:
            context = "\n\n".join(f"[{e['title']}] {e['content']}" for e in evidence)
            try:
                resp = await llm.ainvoke([
                    SystemMessage(content=(
                        "You are a professional, concise customer support agent for this company. "
                        "Use ONLY the provided knowledge. Never invent policy or order details. "
                        "Be warm, clear, and action-oriented. Keep replies under 120 words."
                        f"\n\nKNOWLEDGE:\n{context}"
                    )),
                    HumanMessage(content=last_user[:2000]),
                ])
                response_text = resp.content
            except Exception:
                response_text = (
                    "Thank you for reaching out. I've noted your request. "
                    "Please share any order number or account email so I can help further."
                )
        else:
            response_text = (
                "Thank you for contacting us. Please share your order number or a bit more detail "
                "so I can assist you quickly."
            )

    return {
        "proposed_actions": proposed_actions,
        "final_response": response_text,
        "node_history": state.get("node_history", []) + ["specialist_resolution"],
    }


async def qa_and_respond_node(state: WorkforceState) -> Dict[str, Any]:
    response = state.get("final_response") or "I'm here to help. Could you provide more details?"
    should_escalate = state.get("should_escalate", False)
    confidence = state.get("confidence", 1.0)

    # Low confidence or empty response → escalate
    if confidence < 0.35 or not response.strip():
        should_escalate = True
        response = (
            "I want to make sure we handle this correctly. "
            "I'm connecting you with a human specialist who can take it from here."
        )

    # Hard safety: never claim a refund/action completed unless executed
    lower = response.lower()
    if "refund has been processed" in lower or "i've issued the refund" in lower:
        if not any(a.get("result", {}).get("status") == "succeeded" for a in state.get("executed_actions", [])):
            response = (
                "I've prepared the refund request. It requires a quick verification/approval "
                "before the funds are released. You'll receive confirmation shortly."
            )

    return {
        "final_response": response,
        "should_escalate": should_escalate,
        "node_history": state.get("node_history", []) + ["qa_and_respond"],
    }
