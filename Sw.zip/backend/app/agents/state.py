from typing import TypedDict, Annotated, List, Optional, Dict, Any
from langgraph.graph.message import add_messages
from langchain_core.messages import BaseMessage


class WorkforceState(TypedDict):
    """Shared state for the AI Support Workforce graph."""
    
    # Conversation context
    conversation_id: str
    organization_id: str
    customer_id: Optional[str]
    
    # Messages (LangGraph standard)
    messages: Annotated[List[BaseMessage], add_messages]
    
    # Customer intelligence
    customer_context: Dict[str, Any]
    
    # Understanding
    intent: Optional[str]
    intents: List[str]  # multi-intent support
    sentiment: Optional[str]
    urgency: str
    risk_level: str
    confidence: float
    
    # Planning
    plan: List[Dict[str, Any]]
    required_specialists: List[str]
    
    # Investigation results
    investigation_results: Dict[str, Any]
    knowledge_evidence: List[Dict[str, Any]]
    
    # Actions
    proposed_actions: List[Dict[str, Any]]
    executed_actions: List[Dict[str, Any]]
    
    # Decision
    should_escalate: bool
    escalation_reason: Optional[str]
    final_response: Optional[str]
    
    # Metadata
    autonomy_level: int
    node_history: List[str]
    error: Optional[str]
