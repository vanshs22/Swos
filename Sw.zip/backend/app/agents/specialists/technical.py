from typing import Dict, Any
from app.agents.state import WorkforceState


async def technical_specialist(state: WorkforceState) -> Dict[str, Any]:
    msgs = state.get("messages") or []
    text = ""
    for m in reversed(msgs):
        c = getattr(m, "content", None)
        if c:
            text = c.lower()
            break
    level = 1
    if any(w in text for w in ["api", "integration", "webhook", "sdk", "stack trace"]):
        level = 2
    if any(w in text for w in ["bug", "crash", "500", "exception", "reproduce"]):
        level = 3

    result = {
        "specialist": "technical",
        "level": level,
        "needs_engineering": level >= 3,
        "proposed_actions": [],
    }
    if level >= 3:
        result["proposed_actions"].append({
            "tool_name": "create_ticket",
            "action_type": "engineering_ticket",
            "input": {"subject": "Technical issue from support", "priority": "high"},
            "risk_level": "low",
            "requires_approval": False,
        })

    inv = dict(state.get("investigation_results") or {})
    inv["technical"] = result
    return {
        "investigation_results": inv,
        "proposed_actions": (state.get("proposed_actions") or []) + result["proposed_actions"],
        "node_history": state.get("node_history", []) + ["technical_specialist"],
    }
