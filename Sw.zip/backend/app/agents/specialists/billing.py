from typing import Dict, Any
from app.agents.state import WorkforceState
from app.services.policy import evaluate_refund
from app.connectors.registry import get_connector
import re


async def billing_specialist(state: WorkforceState) -> Dict[str, Any]:
    """Billing specialist: refunds, invoices, payment issues."""
    msgs = state.get("messages") or []
    text = ""
    for m in reversed(msgs):
        c = getattr(m, "content", None) or (m.get("content") if isinstance(m, dict) else "")
        if c:
            text = c
            break

    amount_m = re.search(r"\$\s*(\d+(?:\.\d{1,2})?)", text)
    amount = float(amount_m.group(1)) if amount_m else None
    autonomy = state.get("autonomy_level", 2)
    decision, reason = evaluate_refund(amount, autonomy)

    stripe = get_connector("stripe", state.get("organization_id") or "")
    stripe_status = None
    if stripe:
        hc = await stripe.health_check()
        stripe_status = "connected" if hc.success else f"unavailable: {hc.error}"

    result = {
        "specialist": "billing",
        "amount": amount,
        "policy_decision": decision,
        "policy_reason": reason,
        "stripe": stripe_status,
        "proposed_actions": [],
    }
    if decision != "deny":
        result["proposed_actions"].append({
            "tool_name": "create_refund",
            "action_type": "refund",
            "input": {"amount": amount, "reason": "customer_request"},
            "risk_level": "high" if (amount or 0) > 250 else "medium",
            "requires_approval": decision != "auto",
            "policy_decision": decision,
            "policy_reason": reason,
        })

    inv = dict(state.get("investigation_results") or {})
    inv["billing"] = result
    return {
        "investigation_results": inv,
        "proposed_actions": (state.get("proposed_actions") or []) + result["proposed_actions"],
        "node_history": state.get("node_history", []) + ["billing_specialist"],
    }
