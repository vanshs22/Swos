from typing import Dict, Any
from app.agents.state import WorkforceState


async def retention_specialist(state: WorkforceState) -> Dict[str, Any]:
    msgs = state.get("messages") or []
    text = ""
    for m in reversed(msgs):
        c = getattr(m, "content", None)
        if c:
            text = c.lower()
            break
    cancel_intent = any(w in text for w in ["cancel", "cancelling", "closing account", "unsubscribe"])
    result = {
        "specialist": "retention",
        "cancellation_intent": cancel_intent,
        "offer_eligible": cancel_intent,
        "suggested_offer": "Review retention policy offer (discount / pause) if approved by policy" if cancel_intent else None,
        "proposed_actions": [],
    }
    if cancel_intent:
        result["proposed_actions"].append({
            "tool_name": "create_ticket",
            "action_type": "retention_review",
            "input": {"subject": "Cancellation / retention", "priority": "high"},
            "risk_level": "medium",
            "requires_approval": True,
        })
    inv = dict(state.get("investigation_results") or {})
    inv["retention"] = result
    return {
        "investigation_results": inv,
        "proposed_actions": (state.get("proposed_actions") or []) + result["proposed_actions"],
        "node_history": state.get("node_history", []) + ["retention_specialist"],
    }
