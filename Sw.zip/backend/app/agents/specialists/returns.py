from typing import Dict, Any
from app.agents.state import WorkforceState
from app.services.policy import DEFAULT_POLICIES
import re


async def returns_specialist(state: WorkforceState) -> Dict[str, Any]:
    msgs = state.get("messages") or []
    text = (getattr(msgs[-1], "content", "") if msgs else "") or ""
    for m in reversed(msgs):
        c = getattr(m, "content", None)
        if c:
            text = c
            break
    order_m = re.search(r"(?:order\s*#?\s*|#)(\d{3,})", text, re.I)
    order_id = order_m.group(1) if order_m else None
    damaged = any(w in text.lower() for w in ["damaged", "broken", "defective", "wrong item"])

    policy = DEFAULT_POLICIES.get("return", {})
    result = {
        "specialist": "returns",
        "order_id": order_id,
        "damaged": damaged,
        "window_days": policy.get("window_days", 30),
        "eligible_hint": True if order_id else False,
        "proposed_actions": [],
    }
    if order_id:
        result["proposed_actions"].append({
            "tool_name": "create_ticket",
            "action_type": "return_request",
            "input": {"subject": f"Return for order #{order_id}", "priority": "normal"},
            "risk_level": "medium",
            "requires_approval": False,
        })

    inv = dict(state.get("investigation_results") or {})
    inv["returns"] = result
    return {
        "investigation_results": inv,
        "proposed_actions": (state.get("proposed_actions") or []) + result["proposed_actions"],
        "node_history": state.get("node_history", []) + ["returns_specialist"],
    }
