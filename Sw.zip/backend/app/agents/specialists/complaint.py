from typing import Dict, Any
from app.agents.state import WorkforceState
from app.services.policy import check_escalation_triggers


async def complaint_specialist(state: WorkforceState) -> Dict[str, Any]:
    msgs = state.get("messages") or []
    text = ""
    for m in reversed(msgs):
        c = getattr(m, "content", None)
        if c:
            text = c
            break
    risk = state.get("risk_level", "normal")
    urgency = state.get("urgency", "normal")
    vip = bool((state.get("customer_context") or {}).get("customer", {}).get("vip"))
    escalate, reason = check_escalation_triggers(text, risk, urgency, is_vip=vip)

    result = {
        "specialist": "complaint",
        "should_escalate": escalate,
        "reason": reason,
        "tone": "empathetic_deescalation",
    }
    inv = dict(state.get("investigation_results") or {})
    inv["complaint"] = result
    out: Dict[str, Any] = {
        "investigation_results": inv,
        "node_history": state.get("node_history", []) + ["complaint_specialist"],
    }
    if escalate:
        out["should_escalate"] = True
        out["escalation_reason"] = reason
    return out
