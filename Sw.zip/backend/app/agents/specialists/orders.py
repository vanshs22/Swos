from typing import Dict, Any
from app.agents.state import WorkforceState
from app.connectors.registry import get_connector
import re


async def order_specialist(state: WorkforceState) -> Dict[str, Any]:
    msgs = state.get("messages") or []
    text = ""
    for m in reversed(msgs):
        c = getattr(m, "content", None) or (m.get("content") if isinstance(m, dict) else "")
        if c:
            text = c
            break
    order_m = re.search(r"(?:order\s*#?\s*|#)(\d{3,})", text, re.I)
    order_id = order_m.group(1) if order_m else None

    shopify = get_connector("shopify", state.get("organization_id") or "")
    order_data = None
    shopify_status = None
    if shopify and order_id:
        hc = await shopify.health_check()
        shopify_status = "connected" if hc.success else f"unavailable: {hc.error}"
        if hc.success:
            res = await shopify.get_order(order_id)
            if res.success:
                order_data = res.data

    result = {
        "specialist": "order",
        "order_id": order_id,
        "order_data": order_data,
        "shopify": shopify_status,
        "proposed_actions": [],
    }
    if order_id:
        result["proposed_actions"].append({
            "tool_name": "lookup_order",
            "action_type": "order_lookup",
            "input": {"order_id": order_id},
            "risk_level": "low",
            "requires_approval": False,
        })

    inv = dict(state.get("investigation_results") or {})
    inv["order"] = result
    return {
        "investigation_results": inv,
        "proposed_actions": (state.get("proposed_actions") or []) + result["proposed_actions"],
        "node_history": state.get("node_history", []) + ["order_specialist"],
    }
