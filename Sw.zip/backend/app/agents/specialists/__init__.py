from app.agents.specialists.billing import billing_specialist
from app.agents.specialists.orders import order_specialist
from app.agents.specialists.returns import returns_specialist
from app.agents.specialists.technical import technical_specialist
from app.agents.specialists.complaint import complaint_specialist
from app.agents.specialists.retention import retention_specialist

SPECIALISTS = {
    "billing": billing_specialist,
    "order": order_specialist,
    "returns": returns_specialist,
    "technical": technical_specialist,
    "complaint": complaint_specialist,
    "retention": retention_specialist,
}
