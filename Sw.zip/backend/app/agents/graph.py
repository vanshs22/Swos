"""
Main Workforce Graph — orchestrator + specialist fan-out + QA.
"""
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver

# Production deployments should provide langgraph-checkpoint-postgres. The memory saver is
# intentionally retained only for local development/test mode.
def _build_checkpointer():
    from app.core.config import settings
    if settings.ENVIRONMENT.lower() in {"production", "prod"}:
        try:
            from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
            return AsyncPostgresSaver.from_conn_string(settings.DATABASE_URL)
        except Exception as exc:
            raise RuntimeError("Production requires langgraph-checkpoint-postgres and a PostgreSQL checkpointer") from exc
    return MemorySaver()
from app.agents.state import WorkforceState
from app.agents.orchestrator import (
    identify_customer_node,
    intent_analysis_node,
    risk_and_route_node,
    knowledge_node,
    specialist_resolution_node,
    qa_and_respond_node,
)
from app.agents.specialists.billing import billing_specialist
from app.agents.specialists.orders import order_specialist
from app.agents.specialists.returns import returns_specialist
from app.agents.specialists.technical import technical_specialist
from app.agents.specialists.complaint import complaint_specialist
from app.agents.specialists.retention import retention_specialist


async def run_specialists_node(state: WorkforceState) -> dict:
    """Dispatch to required specialists sequentially (parallel-ready structure)."""
    required = state.get("required_specialists") or ["knowledge"]
    mapping = {
        "billing": billing_specialist,
        "order": order_specialist,
        "orders": order_specialist,
        "returns": returns_specialist,
        "technical": technical_specialist,
        "complaint": complaint_specialist,
        "retention": retention_specialist,
    }
    # Start from current state; each specialist merges investigation_results
    current = dict(state)
    for name in required:
        fn = mapping.get(name)
        if not fn:
            continue
        update = await fn(current)  # type: ignore
        # merge
        for k, v in update.items():
            if k == "investigation_results":
                inv = dict(current.get("investigation_results") or {})
                inv.update(v or {})
                current["investigation_results"] = inv
            elif k == "proposed_actions":
                current["proposed_actions"] = list(current.get("proposed_actions") or []) + list(v or [])
            elif k == "node_history":
                current["node_history"] = list(v or [])
            elif k == "should_escalate" and v:
                current["should_escalate"] = True
            elif k == "escalation_reason" and v:
                current["escalation_reason"] = v
            else:
                current[k] = v
    return {
        "investigation_results": current.get("investigation_results") or {},
        "proposed_actions": current.get("proposed_actions") or [],
        "should_escalate": current.get("should_escalate", state.get("should_escalate")),
        "escalation_reason": current.get("escalation_reason"),
        "node_history": current.get("node_history") or state.get("node_history", []),
    }


def build_workforce_graph():
    graph = StateGraph(WorkforceState)

    graph.add_node("identify_customer", identify_customer_node)
    graph.add_node("intent_analysis", intent_analysis_node)
    graph.add_node("risk_and_route", risk_and_route_node)
    graph.add_node("knowledge", knowledge_node)
    graph.add_node("specialists", run_specialists_node)
    graph.add_node("specialist_resolution", specialist_resolution_node)
    graph.add_node("qa_and_respond", qa_and_respond_node)

    graph.set_entry_point("identify_customer")
    graph.add_edge("identify_customer", "intent_analysis")
    graph.add_edge("intent_analysis", "risk_and_route")
    graph.add_edge("risk_and_route", "knowledge")
    graph.add_edge("knowledge", "specialists")
    graph.add_edge("specialists", "specialist_resolution")
    graph.add_edge("specialist_resolution", "qa_and_respond")
    graph.add_edge("qa_and_respond", END)

    memory = _build_checkpointer()
    return graph.compile(checkpointer=memory)


workforce_graph = build_workforce_graph()
