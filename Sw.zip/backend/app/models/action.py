from datetime import datetime, timezone
from sqlalchemy import String, DateTime, ForeignKey, Text, JSON, Float
from sqlalchemy.orm import Mapped, mapped_column
from app.db.base import Base
import uuid


class Action(Base):
    __tablename__ = "actions"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    organization_id: Mapped[str] = mapped_column(String(36), ForeignKey("organizations.id"), nullable=False, index=True)
    conversation_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("conversations.id"), index=True)
    agent_run_id: Mapped[str | None] = mapped_column(String(36), index=True)
    
    # Action definition
    tool_name: Mapped[str] = mapped_column(String(100), nullable=False)
    action_type: Mapped[str] = mapped_column(String(100))  # refund, cancel_order, update_address, etc.
    
    # Proposal & execution
    status: Mapped[str] = mapped_column(String(50), default="proposed")  
    # proposed → validated → approved → executing → succeeded / failed / requires_approval / cancelled
    
    input_payload: Mapped[dict] = mapped_column(JSON, default=dict)
    output_payload: Mapped[dict | None] = mapped_column(JSON)
    
    # Risk & policy
    risk_level: Mapped[str] = mapped_column(String(20), default="low")
    policy_checks: Mapped[dict] = mapped_column(JSON, default=dict)
    requires_approval: Mapped[bool] = mapped_column(default=False)
    
    # Error handling
    error_message: Mapped[str | None] = mapped_column(Text)
    retry_count: Mapped[int] = mapped_column(default=0)
    
    # Idempotency
    idempotency_key: Mapped[str | None] = mapped_column(String(255), unique=True, index=True)
    
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    executed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class ActionApproval(Base):
    __tablename__ = "action_approvals"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    action_id: Mapped[str] = mapped_column(String(36), ForeignKey("actions.id"), nullable=False, index=True)
    organization_id: Mapped[str] = mapped_column(String(36), ForeignKey("organizations.id"), nullable=False, index=True)
    
    requested_by: Mapped[str] = mapped_column(String(36))  # "ai" or user_id
    approved_by: Mapped[str | None] = mapped_column(String(36))
    status: Mapped[str] = mapped_column(String(50), default="pending")  # pending, approved, rejected
    
    reason: Mapped[str | None] = mapped_column(Text)
    decided_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
