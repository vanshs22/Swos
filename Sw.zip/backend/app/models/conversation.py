from datetime import datetime, timezone
from sqlalchemy import String, DateTime, Boolean, ForeignKey, Text, JSON, Integer, Float
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import Base
import uuid


class Conversation(Base):
    __tablename__ = "conversations"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    organization_id: Mapped[str] = mapped_column(String(36), ForeignKey("organizations.id"), nullable=False, index=True)
    customer_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("customers.id"), index=True)
    
    # Channel & status
    channel: Mapped[str] = mapped_column(String(50), default="web_chat")  # web_chat, email, sms, whatsapp, voice, etc.
    status: Mapped[str] = mapped_column(String(50), default="open")  # open, pending, resolved, escalated, closed
    priority: Mapped[str] = mapped_column(String(20), default="normal")  # low, normal, high, urgent, critical
    
    # AI state
    current_intent: Mapped[str | None] = mapped_column(String(100))
    sentiment: Mapped[str | None] = mapped_column(String(50))
    risk_level: Mapped[str] = mapped_column(String(20), default="normal")
    confidence: Mapped[float | None] = mapped_column(Float)
    
    # Ownership
    assigned_to: Mapped[str | None] = mapped_column(String(36))  # user_id or "ai"
    autonomy_level: Mapped[int] = mapped_column(Integer, default=2)
    
    # Summary & metadata
    summary: Mapped[str | None] = mapped_column(Text)
    metadata_: Mapped[dict] = mapped_column("metadata", JSON, default=dict)
    
    # SLA
    first_response_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )

    organization = relationship("Organization", back_populates="conversations")
    customer = relationship("Customer", back_populates="conversations")
    messages = relationship("Message", back_populates="conversation", cascade="all, delete-orphan", order_by="Message.created_at")


class Message(Base):
    __tablename__ = "messages"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    conversation_id: Mapped[str] = mapped_column(String(36), ForeignKey("conversations.id"), nullable=False, index=True)
    organization_id: Mapped[str] = mapped_column(String(36), ForeignKey("organizations.id"), nullable=False, index=True)
    
    # Sender
    role: Mapped[str] = mapped_column(String(20), nullable=False)  # customer, agent, ai, system
    sender_id: Mapped[str | None] = mapped_column(String(36))  # user_id or customer_id
    sender_name: Mapped[str | None] = mapped_column(String(255))
    
    # Content
    content: Mapped[str] = mapped_column(Text, nullable=False)
    content_type: Mapped[str] = mapped_column(String(50), default="text")  # text, html, image, file
    
    # AI metadata
    intent: Mapped[str | None] = mapped_column(String(100))
    confidence: Mapped[float | None] = mapped_column(Float)
    sources: Mapped[list] = mapped_column(JSON, default=list)  # knowledge sources used
    actions_taken: Mapped[list] = mapped_column(JSON, default=list)
    
    # Visibility
    is_internal: Mapped[bool] = mapped_column(Boolean, default=False)  # internal notes
    
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    conversation = relationship("Conversation", back_populates="messages")
