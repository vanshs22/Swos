from datetime import datetime, timezone
from sqlalchemy import String, DateTime, ForeignKey, Text, JSON, Float, Integer
from sqlalchemy.orm import Mapped, mapped_column
from app.db.base import Base
import uuid


class AgentRun(Base):
    __tablename__ = "agent_runs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    organization_id: Mapped[str] = mapped_column(String(36), ForeignKey("organizations.id"), nullable=False, index=True)
    conversation_id: Mapped[str] = mapped_column(String(36), ForeignKey("conversations.id"), nullable=False, index=True)
    
    # Graph execution
    graph_id: Mapped[str] = mapped_column(String(100), default="main_workforce")
    thread_id: Mapped[str | None] = mapped_column(String(100))  # LangGraph thread
    
    status: Mapped[str] = mapped_column(String(50), default="running")  # running, completed, failed, interrupted
    
    # Metrics
    total_tokens: Mapped[int] = mapped_column(Integer, default=0)
    total_cost: Mapped[float] = mapped_column(Float, default=0.0)
    latency_ms: Mapped[int | None] = mapped_column(Integer)
    
    # Trace summary
    nodes_executed: Mapped[list] = mapped_column(JSON, default=list)
    decisions: Mapped[dict] = mapped_column(JSON, default=dict)
    error: Mapped[str | None] = mapped_column(Text)
    
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
