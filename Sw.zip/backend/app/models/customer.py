from datetime import datetime, timezone
from sqlalchemy import String, DateTime, Boolean, ForeignKey, Text, JSON, Float
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import Base
import uuid


class Customer(Base):
    __tablename__ = "customers"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    organization_id: Mapped[str] = mapped_column(String(36), ForeignKey("organizations.id"), nullable=False, index=True)
    
    # Canonical identity
    email: Mapped[str | None] = mapped_column(String(255), index=True)
    phone: Mapped[str | None] = mapped_column(String(50), index=True)
    full_name: Mapped[str | None] = mapped_column(String(255))
    
    # Status & value
    status: Mapped[str] = mapped_column(String(50), default="active")  # active, at_risk, churned, vip
    lifetime_value: Mapped[float] = mapped_column(Float, default=0.0)
    vip: Mapped[bool] = mapped_column(Boolean, default=False)
    
    # Preferences & context
    language: Mapped[str] = mapped_column(String(10), default="en")
    timezone: Mapped[str | None] = mapped_column(String(50))
    preferences: Mapped[dict] = mapped_column(JSON, default=dict)
    metadata_: Mapped[dict] = mapped_column("metadata", JSON, default=dict)
    
    # Health signals
    support_volume: Mapped[int] = mapped_column(default=0)
    last_interaction_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )

    organization = relationship("Organization", back_populates="customers")
    identities = relationship("CustomerIdentity", back_populates="customer", cascade="all, delete-orphan")
    conversations = relationship("Conversation", back_populates="customer")


class CustomerIdentity(Base):
    """Entity resolution: links external system IDs to canonical customer."""
    __tablename__ = "customer_identities"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    customer_id: Mapped[str] = mapped_column(String(36), ForeignKey("customers.id"), nullable=False, index=True)
    organization_id: Mapped[str] = mapped_column(String(36), ForeignKey("organizations.id"), nullable=False, index=True)
    
    provider: Mapped[str] = mapped_column(String(50), nullable=False)  # shopify, stripe, zendesk, email, etc.
    external_id: Mapped[str] = mapped_column(String(255), nullable=False)
    
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    customer = relationship("Customer", back_populates="identities")
