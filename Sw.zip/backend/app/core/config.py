from pydantic_settings import BaseSettings
from typing import Optional, List
import secrets
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent.parent


class Settings(BaseSettings):
    # App
    APP_NAME: str = "AI Support Workforce"
    APP_VERSION: str = "1.0.0"
    ENVIRONMENT: str = "development"
    DEBUG: bool = False
    DOCS_ENABLED: bool = True
    JWT_ISSUER: str = "support-workforce"
    JWT_AUDIENCE: str = "support-workforce-api"
    ENCRYPTION_KEY: str = ""
    API_V1_PREFIX: str = "/api/v1"

    # Security
    SECRET_KEY: str = ""
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 12
    REFRESH_TOKEN_EXPIRE_DAYS: int = 14

    # -------------------------------------------------------------------------
    # Database — Supabase (Postgres) primary, SQLite fallback for local demo
    # -------------------------------------------------------------------------
    # Supabase: Project Settings → Database → Connection string (URI)
    # Use the "Transaction" pooler or direct connection.
    # Example:
    #   postgresql+asyncpg://postgres.[ref]:[password]@aws-0-[region].pooler.supabase.com:6543/postgres
    # Or direct:
    #   postgresql+asyncpg://postgres:[password]@db.[ref].supabase.co:5432/postgres
    DATABASE_URL: str = "sqlite+aiosqlite:///./support_workforce.db"

    # Supabase extras (optional — for Storage / Realtime / Auth later)
    SUPABASE_URL: Optional[str] = None
    SUPABASE_ANON_KEY: Optional[str] = None
    SUPABASE_SERVICE_ROLE_KEY: Optional[str] = None

    # AI / LLM
    OPENAI_API_KEY: Optional[str] = None
    DEFAULT_MODEL: str = "gpt-4o-mini"
    EMBEDDING_MODEL: str = "text-embedding-3-small"

    # CORS
    TRUSTED_HOSTS: List[str] = ["localhost", "127.0.0.1"]

    CORS_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:8000",
        "http://127.0.0.1:8000",
    ]

    # Safety & limits
    MAX_ACTIONS_PER_CONVERSATION: int = 25
    DEFAULT_AUTONOMY_LEVEL: int = 2
    MAX_MESSAGE_LENGTH: int = 8000

    # Feature flags
    ENABLE_LEARNING_LOOP: bool = True
    ENABLE_PROACTIVE: bool = False
    ENABLE_VOICE: bool = False

    class Config:
        env_file = ".env"
        case_sensitive = True

    def validate_runtime(self) -> None:
        if self.ENVIRONMENT.lower() in {"production", "prod"}:
            if not self.SECRET_KEY or len(self.SECRET_KEY) < 32:
                raise RuntimeError("SECRET_KEY must be set to a stable value of at least 32 characters in production")
            if self.DEBUG:
                raise RuntimeError("DEBUG must be false in production")
            if any(origin == "*" for origin in self.CORS_ORIGINS):
                raise RuntimeError("Wildcard CORS is not allowed in production")
            if not self.TRUSTED_HOSTS:
                raise RuntimeError("TRUSTED_HOSTS must be configured in production")
            if self.DATABASE_URL.startswith("sqlite"):
                raise RuntimeError("Production requires PostgreSQL; SQLite is for local development only")
            if not self.ENCRYPTION_KEY or len(self.ENCRYPTION_KEY) < 32:
                raise RuntimeError("ENCRYPTION_KEY must be set to a stable value of at least 32 characters in production")
            if self.DOCS_ENABLED:
                raise RuntimeError("DOCS_ENABLED must be false in production")


settings = Settings()
settings.validate_runtime()
