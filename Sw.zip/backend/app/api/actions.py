from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List, Optional
from pydantic import BaseModel
from datetime import datetime, timezone

from app.db.session import get_db
from app.api.deps import get_current_user, get_current_org
from app.models.user import User
from app.models.organization import Organization
from app.models.action import Action, ActionApproval
from app.tools.gateway import tool_gateway
from app.api.rbac import require_roles

router = APIRouter(prefix="/actions", tags=["actions"])


class ApprovalDecision(BaseModel):
    decision: str  # approve | reject
    reason: Optional[str] = None


@router.get("")
async def list_actions(
    status: Optional[str] = None,
    user: User = Depends(require_roles("owner", "admin", "manager")),
    org: Organization = Depends(get_current_org),
    db: AsyncSession = Depends(get_db),
):
    q = select(Action).where(Action.organization_id == org.id).order_by(Action.created_at.desc()).limit(100)
    if status:
        q = q.where(Action.status == status)
    result = await db.execute(q)
    actions = result.scalars().all()
    return [
        {
            "id": a.id,
            "tool_name": a.tool_name,
            "action_type": a.action_type,
            "status": a.status,
            "risk_level": a.risk_level,
            "requires_approval": a.requires_approval,
            "input_payload": a.input_payload,
            "output_payload": a.output_payload,
            "conversation_id": a.conversation_id,
            "created_at": a.created_at.isoformat() if a.created_at else None,
            "executed_at": a.executed_at.isoformat() if a.executed_at else None,
        }
        for a in actions
    ]


@router.get("/pending")
async def pending_approvals(
    user: User = Depends(require_roles("owner", "admin", "manager")),
    org: Organization = Depends(get_current_org),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Action).where(
            Action.organization_id == org.id,
            Action.status.in_(["proposed", "requires_approval"]),
            Action.requires_approval == True,
        ).order_by(Action.created_at.asc())
    )
    actions = result.scalars().all()
    return [
        {
            "id": a.id,
            "tool_name": a.tool_name,
            "action_type": a.action_type,
            "status": a.status,
            "risk_level": a.risk_level,
            "input_payload": a.input_payload,
            "conversation_id": a.conversation_id,
            "created_at": a.created_at.isoformat() if a.created_at else None,
        }
        for a in actions
    ]


@router.post("/{action_id}/decide")
async def decide_action(
    action_id: str,
    body: ApprovalDecision,
    user: User = Depends(require_roles("owner", "admin", "manager")),
    org: Organization = Depends(get_current_org),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Action).where(Action.id == action_id, Action.organization_id == org.id)
    )
    action = result.scalar_one_or_none()
    if not action:
        raise HTTPException(status_code=404, detail="Action not found")

    if body.decision not in ("approve", "reject"):
        raise HTTPException(status_code=422, detail="decision must be approve or reject")
    if action.status not in ("proposed", "requires_approval"):
        raise HTTPException(status_code=400, detail=f"Action already in status {action.status}")
    if body.decision == "approve" and not action.requires_approval:
        raise HTTPException(status_code=400, detail="Action does not require approval")

    approval = ActionApproval(
        action_id=action.id,
        organization_id=org.id,
        requested_by="ai",
        approved_by=user.id,
        status="approved" if body.decision == "approve" else "rejected",
        reason=body.reason,
        decided_at=datetime.now(timezone.utc),
    )
    db.add(approval)

    if body.decision == "approve":
        # Execute via gateway with elevated autonomy for this call
        exec_result = await tool_gateway.execute(
            tool_id=action.tool_name,
            payload=action.input_payload or {},
            organization_id=org.id,
            actor_id=user.id,
            autonomy_level=4,  # human-approved
            human_approved=True,
            idempotency_key=action.idempotency_key or action.id,
        )
        action.status = "succeeded" if exec_result.get("success") else "failed"
        action.output_payload = exec_result
        action.executed_at = datetime.now(timezone.utc)
        if not exec_result.get("success"):
            action.error_message = exec_result.get("error") or exec_result.get("message")
    else:
        action.status = "cancelled"

    await db.commit()
    return {"status": action.status, "action_id": action.id}
