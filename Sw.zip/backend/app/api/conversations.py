from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from typing import List, Optional
from datetime import datetime, timezone
import uuid
import hashlib
import json

from app.db.session import get_db
from app.api.deps import get_current_user, get_current_org
from app.models.user import User
from app.models.organization import Organization
from app.models.customer import Customer
from app.models.conversation import Conversation, Message
from app.models.action import Action
from app.models.agent_run import AgentRun
from app.schemas.conversation import (
    ConversationCreate,
    ConversationResponse,
    ConversationListItem,
    MessageCreate,
    MessageResponse,
)
from app.services.workforce import process_message
from app.services.entity_resolution import resolve_customer, build_customer_context

router = APIRouter(prefix="/conversations", tags=["conversations"])


async def _persist_actions(
    db: AsyncSession,
    org_id: str,
    conv_id: str,
    run_id: Optional[str],
    proposed: list,
    pending: list,
):
    # Prefer pending (already marked requires_approval); dedupe by tool+input
    seen = set()
    items = []
    for a in (pending or []) + (proposed or []):
        key = (a.get("tool_name"), str(a.get("input") or a.get("input_payload")))
        if key in seen:
            continue
        seen.add(key)
        items.append(a)
    for a in items:
        status = "requires_approval" if a.get("requires_approval") or (a.get("result") or {}).get("status") == "requires_approval" else "proposed"
        if (a.get("result") or {}).get("status") == "succeeded":
            status = "succeeded"
        act = Action(
            organization_id=org_id,
            conversation_id=conv_id,
            agent_run_id=run_id,
            tool_name=a.get("tool_name", "unknown"),
            action_type=a.get("action_type"),
            status=status,
            input_payload=a.get("input") or a.get("input_payload") or {},
            output_payload=a.get("result"),
            risk_level=a.get("risk_level", "medium"),
            requires_approval=bool(a.get("requires_approval")),
            policy_checks={"decision": a.get("policy_decision"), "reason": a.get("policy_reason")},
            idempotency_key=hashlib.sha256((org_id + ":" + conv_id + ":" + a.get("tool_name", "unknown") + ":" + json.dumps(a.get("input") or a.get("input_payload") or {}, sort_keys=True, default=str)).encode()).hexdigest(),
        )
        if status == "succeeded":
            act.executed_at = datetime.now(timezone.utc)
        db.add(act)


@router.post("", response_model=ConversationResponse)
async def create_conversation(
    data: ConversationCreate,
    user: User = Depends(get_current_user),
    org: Organization = Depends(get_current_org),
    db: AsyncSession = Depends(get_db),
):
    customer = None
    customer_context = {}
    if data.customer_email or data.customer_name:
        customer = await resolve_customer(
            db,
            organization_id=org.id,
            email=data.customer_email,
            full_name=data.customer_name,
        )
        customer_context = await build_customer_context(db, customer)

    conv = Conversation(
        organization_id=org.id,
        customer_id=customer.id if customer else None,
        channel=data.channel,
        status="open",
        assigned_to="ai",
        autonomy_level=org.autonomy_level,
    )
    db.add(conv)
    await db.flush()

    msg = Message(
        conversation_id=conv.id,
        organization_id=org.id,
        role="customer",
        sender_id=customer.id if customer else None,
        sender_name=data.customer_name or data.customer_email,
        content=data.initial_message,
    )
    db.add(msg)
    await db.flush()

    # Agent run record
    run = AgentRun(
        organization_id=org.id,
        conversation_id=conv.id,
        status="running",
    )
    db.add(run)
    await db.flush()

    ai_result = await process_message(
        conversation_id=conv.id,
        organization_id=org.id,
        user_message=data.initial_message,
        customer_id=customer.id if customer else None,
        autonomy_level=org.autonomy_level,
        customer_context=customer_context,
    )

    ai_msg = Message(
        conversation_id=conv.id,
        organization_id=org.id,
        role="ai",
        sender_name="AI Support",
        content=ai_result.get("response") or "Thank you for contacting us.",
        intent=ai_result.get("intent"),
        confidence=ai_result.get("confidence"),
        sources=ai_result.get("knowledge_sources") or [],
        actions_taken=ai_result.get("executed_actions") or [],
    )
    db.add(ai_msg)

    conv.current_intent = ai_result.get("intent")
    conv.sentiment = ai_result.get("sentiment")
    conv.risk_level = ai_result.get("risk_level", "normal")
    conv.confidence = ai_result.get("confidence")
    if ai_result.get("should_escalate"):
        conv.status = "escalated"
        conv.assigned_to = None

    run.status = "completed"
    run.nodes_executed = ai_result.get("node_history") or []
    run.decisions = {
        "intent": ai_result.get("intent"),
        "escalated": ai_result.get("should_escalate"),
        "reason": ai_result.get("escalation_reason"),
    }
    run.completed_at = datetime.now(timezone.utc)

    await _persist_actions(
        db, org.id, conv.id, run.id,
        ai_result.get("proposed_actions"),
        ai_result.get("pending_approval_actions"),
    )

    await db.commit()

    result = await db.execute(
        select(Conversation)
        .options(selectinload(Conversation.messages))
        .where(Conversation.id == conv.id)
    )
    return result.scalar_one()


@router.get("", response_model=List[ConversationListItem])
async def list_conversations(
    status: Optional[str] = None,
    user: User = Depends(get_current_user),
    org: Organization = Depends(get_current_org),
    db: AsyncSession = Depends(get_db),
):
    q = select(Conversation).where(Conversation.organization_id == org.id)
    if status:
        q = q.where(Conversation.status == status)
    q = q.order_by(Conversation.updated_at.desc()).limit(50)
    result = await db.execute(q)
    convs = result.scalars().all()
    return [
        ConversationListItem(
            id=c.id,
            channel=c.channel,
            status=c.status,
            priority=c.priority,
            current_intent=c.current_intent,
            sentiment=c.sentiment,
            summary=c.summary,
            created_at=c.created_at,
            updated_at=c.updated_at,
        )
        for c in convs
    ]


@router.get("/{conversation_id}", response_model=ConversationResponse)
async def get_conversation(
    conversation_id: str,
    user: User = Depends(get_current_user),
    org: Organization = Depends(get_current_org),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Conversation)
        .options(selectinload(Conversation.messages))
        .where(
            Conversation.id == conversation_id,
            Conversation.organization_id == org.id,
        )
    )
    conv = result.scalar_one_or_none()
    if not conv:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return conv


@router.post("/{conversation_id}/messages", response_model=MessageResponse)
async def send_message(
    conversation_id: str,
    data: MessageCreate,
    user: User = Depends(get_current_user),
    org: Organization = Depends(get_current_org),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Conversation).where(
            Conversation.id == conversation_id,
            Conversation.organization_id == org.id,
        )
    )
    conv = result.scalar_one_or_none()
    if not conv:
        raise HTTPException(status_code=404, detail="Conversation not found")

    msg = Message(
        conversation_id=conv.id,
        organization_id=org.id,
        role="customer",
        content=data.content[:8000],
        content_type=data.content_type,
    )
    db.add(msg)
    await db.flush()

    run = AgentRun(
        organization_id=org.id,
        conversation_id=conv.id,
        status="running",
    )
    db.add(run)
    await db.flush()

    ai_result = await process_message(
        conversation_id=conv.id,
        organization_id=org.id,
        user_message=data.content,
        customer_id=conv.customer_id,
        autonomy_level=conv.autonomy_level or org.autonomy_level,
    )

    ai_msg = Message(
        conversation_id=conv.id,
        organization_id=org.id,
        role="ai",
        sender_name="AI Support",
        content=ai_result.get("response") or "Got it.",
        intent=ai_result.get("intent"),
        confidence=ai_result.get("confidence"),
        sources=ai_result.get("knowledge_sources") or [],
        actions_taken=ai_result.get("executed_actions") or [],
    )
    db.add(ai_msg)

    conv.current_intent = ai_result.get("intent")
    conv.sentiment = ai_result.get("sentiment")
    conv.risk_level = ai_result.get("risk_level", "normal")
    conv.confidence = ai_result.get("confidence")
    if ai_result.get("should_escalate"):
        conv.status = "escalated"

    run.status = "completed"
    run.nodes_executed = ai_result.get("node_history") or []
    run.decisions = {
        "intent": ai_result.get("intent"),
        "escalated": ai_result.get("should_escalate"),
    }
    run.completed_at = datetime.now(timezone.utc)

    await _persist_actions(
        db, org.id, conv.id, run.id,
        ai_result.get("proposed_actions"),
        ai_result.get("pending_approval_actions"),
    )

    await db.commit()
    await db.refresh(ai_msg)
    return ai_msg


@router.post("/{conversation_id}/takeover")
async def takeover(
    conversation_id: str,
    user: User = Depends(get_current_user),
    org: Organization = Depends(get_current_org),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Conversation).where(
            Conversation.id == conversation_id,
            Conversation.organization_id == org.id,
        )
    )
    conv = result.scalar_one_or_none()
    if not conv:
        raise HTTPException(status_code=404, detail="Conversation not found")
    conv.assigned_to = user.id
    conv.status = "pending"
    await db.commit()
    return {"status": "taken_over", "assigned_to": user.id}
