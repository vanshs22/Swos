from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from datetime import datetime, timezone

from app.db.session import get_db
from app.core.security import (
    verify_password,
    get_password_hash,
    create_access_token,
    create_refresh_token,
    decode_token,
)
from app.schemas.auth import LoginRequest, TokenResponse, UserCreate, UserResponse
from pydantic import BaseModel
from app.models.user import User, UserRole
from app.models.organization import Organization
import re
import uuid

router = APIRouter(prefix="/auth", tags=["auth"])


def slugify(name: str) -> str:
    s = re.sub(r"[^\w\s-]", "", name.lower())
    return re.sub(r"[-\s]+", "-", s).strip("-")[:80]


@router.post("/signup", response_model=TokenResponse)
async def signup(data: UserCreate, db: AsyncSession = Depends(get_db)):
    # Check existing email
    existing = await db.execute(select(User).where(User.email == data.email))
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Email already registered")

    org_name = data.organization_name or f"{data.full_name}'s Workspace"
    org_slug = slugify(org_name) + "-" + str(uuid.uuid4())[:8]

    org = Organization(name=org_name, slug=org_slug)
    db.add(org)
    await db.flush()

    try:
        password_hash = get_password_hash(data.password)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    user = User(
        organization_id=org.id,
        email=data.email,
        hashed_password=password_hash,
        full_name=data.full_name,
        role=UserRole.OWNER.value,
    )
    db.add(user)
    await db.commit()

    access = create_access_token(user.id, org.id, user.role)
    refresh = create_refresh_token(user.id, org.id, user.role)
    return TokenResponse(access_token=access, refresh_token=refresh)


@router.post("/login", response_model=TokenResponse)
async def login(data: LoginRequest, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.email == data.email))
    user = result.scalar_one_or_none()
    if not user or not verify_password(data.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Incorrect email or password")
    if not user.is_active:
        raise HTTPException(status_code=403, detail="Account disabled")

    user.last_login_at = datetime.now(timezone.utc)
    await db.commit()

    access = create_access_token(user.id, user.organization_id, user.role)
    refresh = create_refresh_token(user.id, user.organization_id, user.role)
    return TokenResponse(access_token=access, refresh_token=refresh)


class RefreshRequest(BaseModel):
    refresh_token: str


@router.post("/refresh", response_model=TokenResponse)
async def refresh(data: RefreshRequest, db: AsyncSession = Depends(get_db)):
    payload = decode_token(data.refresh_token, expected_type="refresh")
    result = await db.execute(select(User).where(User.id == payload.sub, User.organization_id == payload.org))
    user = result.scalar_one_or_none()
    if not user or not user.is_active:
        raise HTTPException(status_code=401, detail="User not found or inactive")
    return TokenResponse(
        access_token=create_access_token(user.id, user.organization_id, user.role),
        refresh_token=create_refresh_token(user.id, user.organization_id, user.role),
    )


from app.api.deps import get_current_user as get_user_dep

@router.get("/me", response_model=UserResponse)
async def me(user: User = Depends(get_user_dep)):
    return user
