from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from app.db.session import get_db
from app.api.deps import get_current_user, get_current_org
from app.models.user import User
from app.models.organization import Organization
from app.models.conversation import Conversation
from app.models.action import Action
from app.models.customer import Customer

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


@router.get("/stats")
async def workforce_stats(
    user: User = Depends(get_current_user),
    org: Organization = Depends(get_current_org),
    db: AsyncSession = Depends(get_db),
):
    org_id = org.id

    total_q = await db.execute(
        select(func.count()).select_from(Conversation).where(Conversation.organization_id == org_id)
    )
    total = total_q.scalar() or 0

    resolved_q = await db.execute(
        select(func.count()).select_from(Conversation).where(
            Conversation.organization_id == org_id,
            Conversation.status.in_(["resolved", "closed"]),
        )
    )
    resolved = resolved_q.scalar() or 0

    escalated_q = await db.execute(
        select(func.count()).select_from(Conversation).where(
            Conversation.organization_id == org_id,
            Conversation.status == "escalated",
        )
    )
    escalated = escalated_q.scalar() or 0

    open_q = await db.execute(
        select(func.count()).select_from(Conversation).where(
            Conversation.organization_id == org_id,
            Conversation.status.in_(["open", "pending"]),
        )
    )
    open_count = open_q.scalar() or 0

    customers_q = await db.execute(
        select(func.count()).select_from(Customer).where(Customer.organization_id == org_id)
    )
    customers = customers_q.scalar() or 0

    pending_actions_q = await db.execute(
        select(func.count()).select_from(Action).where(
            Action.organization_id == org_id,
            Action.status.in_(["proposed", "requires_approval"]),
        )
    )
    pending_actions = pending_actions_q.scalar() or 0

    ai_resolved = max(0, total - escalated - open_count) if total else 0
    resolution_rate = round((resolved / total) * 100, 1) if total else 0.0

    return {
        "workload": {
            "total_conversations": total,
            "open": open_count,
            "ai_handled": ai_resolved,
            "human_escalated": escalated,
            "resolved": resolved,
        },
        "effectiveness": {
            "resolution_rate_pct": resolution_rate,
            "automation_hint": f"{resolution_rate}% resolved",
        },
        "attention": {
            "sla_risks": 0,  # placeholder
            "pending_approvals": pending_actions,
            "open_escalations": escalated,
        },
        "customers": customers,
        "organization": {
            "id": org.id,
            "name": org.name,
            "autonomy_level": org.autonomy_level,
        },
    }
