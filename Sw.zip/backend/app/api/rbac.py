from fastapi import Depends, HTTPException, status
from app.api.deps import get_current_user
from app.models.user import User


def require_roles(*roles: str):
    allowed = set(roles)
    async def dependency(user: User = Depends(get_current_user)) -> User:
        if user.role not in allowed:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Insufficient role")
        return user
    return dependency
