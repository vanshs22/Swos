"""Operations APIs: manager, root cause, eval, knowledge, connectors, health, proactive, versioning, events."""
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel
from typing import Optional
from app.db.session import get_db
from app.api.deps import get_current_user, get_current_org
from app.models.user import User
from app.models.organization import Organization
from app.services.support_manager import generate_daily_report
from app.services.root_cause import detect_root_causes
from app.evaluation.harness import run_evaluation
from app.evaluation.simulation import run_simulation
from app.knowledge.vector_store import ingest_document, search, seed_default_policies
from app.connectors.registry import get_connector, CONNECTOR_TYPES
from app.services.learning import list_proposals
from app.services.proactive import detect_proactive_opportunities
from app.services.feedback_intel import extract_product_feedback
from app.services.customer_health import list_health, score_customer
from app.services.versioning import version_info, set_canary, promote_canary, rollback_canary
from app.services.observability import list_traces
from app.api.rbac import require_roles
from app.events.bus import recent_events

router = APIRouter(prefix="/ops", tags=["operations"])


class KnowledgeIngest(BaseModel):
    title: str
    content: str
    category: str = "general"
    source: str = "admin"
    document_id: Optional[str] = None


class KnowledgeSearch(BaseModel):
    query: str
    n_results: int = 5


class CanaryRequest(BaseModel):
    version: str
    canary_pct: int = 5


@router.get("/support-manager/report")
async def support_manager_report(
    user: User = Depends(get_current_user),
    org: Organization = Depends(get_current_org),
    db: AsyncSession = Depends(get_db),
):
    return await generate_daily_report(db, org.id)


@router.get("/root-cause")
async def root_cause(
    user: User = Depends(get_current_user),
    org: Organization = Depends(get_current_org),
    db: AsyncSession = Depends(get_db),
):
    return await detect_root_causes(db, org.id)


@router.post("/evaluate")
async def evaluate(
    user: User = Depends(require_roles("owner", "admin")),
    org: Organization = Depends(get_current_org),
):
    return await run_evaluation(organization_id=org.id)


@router.post("/simulate")
async def simulate(
    user: User = Depends(require_roles("owner", "admin")),
    org: Organization = Depends(get_current_org),
):
    return await run_simulation(organization_id=org.id)


@router.post("/knowledge/ingest")
async def knowledge_ingest(
    body: KnowledgeIngest,
    user: User = Depends(require_roles("owner", "admin")),
    org: Organization = Depends(get_current_org),
):
    import uuid
    doc_id = body.document_id or str(uuid.uuid4())
    n = ingest_document(org.id, doc_id, body.title, body.content, body.category, body.source)
    return {"document_id": doc_id, "chunks": n}


@router.post("/knowledge/search")
async def knowledge_search(
    body: KnowledgeSearch,
    user: User = Depends(get_current_user),
    org: Organization = Depends(get_current_org),
):
    seed_default_policies(org.id)
    return {"results": search(org.id, body.query, body.n_results)}


@router.get("/knowledge/seed")
async def knowledge_seed(
    user: User = Depends(require_roles("owner", "admin")),
    org: Organization = Depends(get_current_org),
):
    seed_default_policies(org.id)
    return {"status": "seeded"}


@router.get("/connectors")
async def list_connectors(
    user: User = Depends(get_current_user),
    org: Organization = Depends(get_current_org),
):
    out = []
    for name in CONNECTOR_TYPES:
        c = get_connector(name, org.id)
        if c:
            hc = await c.health_check()
            out.append({"name": name, "connected": hc.success, "detail": hc.data or hc.error})
    return {"connectors": out}


@router.get("/learning/proposals")
async def learning_proposals(
    user: User = Depends(get_current_user),
    org: Organization = Depends(get_current_org),
):
    return {"proposals": list_proposals(org.id)}


@router.get("/proactive")
async def proactive(
    user: User = Depends(get_current_user),
    org: Organization = Depends(get_current_org),
    db: AsyncSession = Depends(get_db),
):
    return {"opportunities": await detect_proactive_opportunities(db, org.id)}


@router.get("/feedback")
async def feedback(
    user: User = Depends(get_current_user),
    org: Organization = Depends(get_current_org),
    db: AsyncSession = Depends(get_db),
):
    return await extract_product_feedback(db, org.id)


@router.get("/customer-health")
async def customer_health_list(
    user: User = Depends(get_current_user),
    org: Organization = Depends(get_current_org),
    db: AsyncSession = Depends(get_db),
):
    return {"customers": await list_health(db, org.id)}


@router.get("/customer-health/{customer_id}")
async def customer_health_one(
    customer_id: str,
    user: User = Depends(get_current_user),
    org: Organization = Depends(get_current_org),
    db: AsyncSession = Depends(get_db),
):
    return await score_customer(db, org.id, customer_id)


@router.get("/versions")
async def versions(user: User = Depends(get_current_user)):
    return version_info()


@router.post("/versions/canary")
async def start_canary(body: CanaryRequest, user: User = Depends(require_roles("owner", "admin"))):
    v = set_canary(body.version, canary_pct=body.canary_pct)
    return {"canary": {"version": v.version, "canary_pct": v.canary_pct}}


@router.post("/versions/promote")
async def promote(user: User = Depends(require_roles("owner", "admin"))):
    v = promote_canary()
    return {"production": None if not v else v.version}


@router.post("/versions/rollback-canary")
async def rollback(user: User = Depends(require_roles("owner", "admin"))):
    rollback_canary()
    return {"status": "rolled_back"}


@router.get("/traces")
async def traces(
    user: User = Depends(get_current_user),
    org: Organization = Depends(get_current_org),
):
    return {"traces": list_traces(org.id)}


@router.get("/events")
async def events(
    user: User = Depends(get_current_user),
    org: Organization = Depends(get_current_org),
):
    return {"events": recent_events(org.id)}
