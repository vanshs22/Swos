"""In-process event bus (swap for Redis/NATS in production)."""
from __future__ import annotations
from typing import Any, Callable, Dict, List, Awaitable
from collections import defaultdict
from datetime import datetime, timezone
import asyncio
import uuid

EventHandler = Callable[[Dict[str, Any]], Awaitable[None]]

_handlers: Dict[str, List[EventHandler]] = defaultdict(list)
_history: List[Dict[str, Any]] = []
_MAX_HISTORY = 2000


def subscribe(event_type: str, handler: EventHandler) -> None:
    _handlers[event_type].append(handler)


async def publish(event_type: str, payload: Dict[str, Any], organization_id: str | None = None) -> str:
    event = {
        "id": str(uuid.uuid4()),
        "type": event_type,
        "organization_id": organization_id,
        "payload": payload,
        "ts": datetime.now(timezone.utc).isoformat(),
    }
    _history.append(event)
    if len(_history) > _MAX_HISTORY:
        del _history[: len(_history) - _MAX_HISTORY]
    for h in list(_handlers.get(event_type, [])) + list(_handlers.get("*", [])):
        try:
            await h(event)
        except Exception:
            pass
    return event["id"]


def recent_events(organization_id: str | None = None, limit: int = 50) -> List[Dict[str, Any]]:
    items = _history
    if organization_id:
        items = [e for e in items if e.get("organization_id") == organization_id]
    return list(reversed(items[-limit:]))
