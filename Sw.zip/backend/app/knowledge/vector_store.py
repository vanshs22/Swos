"""
In-process knowledge store with simple TF-IDF-like retrieval.
Fully functional without disk or external embedding services.
(Swap to Chroma/pgvector in production via same interface.)
"""
from __future__ import annotations
from typing import List, Dict, Any, Optional
from collections import defaultdict
import math
import re

# org_id -> list of chunks
_STORE: Dict[str, List[Dict[str, Any]]] = defaultdict(list)


def _tokenize(text: str) -> List[str]:
    return re.findall(r"[a-z0-9$]+", (text or "").lower())


def ingest_document(
    organization_id: str,
    document_id: str,
    title: str,
    content: str,
    category: str = "general",
    source: str = "manual",
    chunk_size: int = 600,
) -> int:
    text = (content or "").strip()
    if not text:
        return 0
    # remove old chunks for doc
    _STORE[organization_id] = [
        c for c in _STORE[organization_id] if c.get("document_id") != document_id
    ]
    step = max(chunk_size - 80, 200)
    n = 0
    i = 0
    while i < len(text):
        piece = text[i : i + chunk_size].strip()
        if piece:
            _STORE[organization_id].append({
                "document_id": document_id,
                "title": title,
                "content": piece,
                "category": category,
                "source": source,
                "chunk_index": n,
                "tokens": set(_tokenize(title + " " + piece)),
            })
            n += 1
        i += step
    return n


def search(
    organization_id: str,
    query: str,
    n_results: int = 5,
    category: Optional[str] = None,
) -> List[Dict[str, Any]]:
    q = set(_tokenize(query))
    if not q:
        return []
    scored = []
    for chunk in _STORE.get(organization_id, []):
        if category and chunk.get("category") != category:
            continue
        overlap = len(q & chunk["tokens"])
        if overlap == 0:
            continue
        # simple score
        score = overlap / (math.sqrt(len(q)) * math.sqrt(max(len(chunk["tokens"]), 1)))
        scored.append((score, chunk))
    scored.sort(key=lambda x: x[0], reverse=True)
    out = []
    for score, chunk in scored[:n_results]:
        out.append({
            "content": chunk["content"],
            "title": chunk["title"],
            "source": chunk["source"],
            "category": chunk["category"],
            "document_id": chunk["document_id"],
            "score": round(score, 4),
        })
    return out


def seed_default_policies(organization_id: str) -> None:
    docs = [
        ("pol_refund", "Refund Policy", "policy",
         "Refunds available within 30 days of purchase for unused or defective items. "
         "Orders under $50 can be refunded automatically when eligibility is confirmed. "
         "$50–$250 require manager approval. Over $1000 require human specialist. "
         "Damaged items: photo evidence recommended. Restocking fee may apply."),
        ("pol_return", "Returns Policy", "policy",
         "Returns accepted within 30 days. Item must be in original condition. "
         "Free return shipping for defective items. Restocking fee may apply for opened non-defective items."),
        ("pol_order", "Order Tracking", "howto",
         "Track orders with the number in your shipping confirmation email. "
         "Standard delivery 3–5 business days. Express 1–2 days."),
        ("pol_cancel", "Cancellation Policy", "policy",
         "Unshipped orders can usually be cancelled immediately. Shipped orders must go through return process. "
         "Subscriptions can be cancelled anytime; access continues until end of billing period."),
        ("pol_billing", "Billing Help", "howto",
         "View invoices in your account portal. Failed payments are retried automatically. "
         "For disputes provide the transaction ID."),
        ("pol_tech", "Technical Support", "howto",
         "For login issues try password reset. Clear cache if the app misbehaves. "
         "Share device, browser, and screenshots for persistent errors."),
    ]
    for doc_id, title, cat, content in docs:
        ingest_document(organization_id, doc_id, title, content, category=cat, source="system")
