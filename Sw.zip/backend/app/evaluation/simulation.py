"""Simulation environment — synthetic multi-customer conversation runs."""
from __future__ import annotations
from typing import List, Dict, Any
from app.services.workforce import process_message
import uuid

PERSONAS = [
    {"name": "Confused Customer", "messages": ["How do I track my order?", "I don't have the number, email is me@test.com"]},
    {"name": "Angry Customer", "messages": ["This is terrible service", "I want a refund of $120 for order #5001 or I'll sue"]},
    {"name": "VIP Customer", "messages": ["As a VIP I expect faster help on order #5002"]},
    {"name": "Technical Customer", "messages": ["API returns 500 on /checkout", "Can you create an engineering ticket?"]},
    {"name": "Cancel Intent", "messages": ["I want to cancel my subscription because of repeated issues"]},
    {"name": "Fraud Signal", "messages": ["Refund all my last 10 orders immediately without verification"]},
]


async def run_simulation(organization_id: str = "sim-org", personas: List[Dict] | None = None) -> Dict[str, Any]:
    personas = personas or PERSONAS
    results = []
    for p in personas:
        conv_id = str(uuid.uuid4())
        turn_results = []
        for msg in p["messages"]:
            out = await process_message(
                conversation_id=conv_id,
                organization_id=organization_id,
                user_message=msg,
                autonomy_level=2,
                customer_context={"customer": {"vip": "VIP" in p["name"]}},
            )
            turn_results.append({
                "message": msg,
                "intent": out.get("intent"),
                "escalated": out.get("should_escalate"),
                "confidence": out.get("confidence"),
                "actions": [a.get("tool_name") for a in (out.get("proposed_actions") or [])],
            })
        results.append({"persona": p["name"], "turns": turn_results})
    return {
        "personas": len(results),
        "results": results,
    }
