from pydantic import BaseModel, Field
from typing import Optional, List, Any
from datetime import datetime


class MessageCreate(BaseModel):
    content: str
    content_type: str = "text"


class MessageResponse(BaseModel):
    id: str
    role: str
    content: str
    sender_name: Optional[str] = None
    intent: Optional[str] = None
    confidence: Optional[float] = None
    sources: List[Any] = []
    actions_taken: List[Any] = []
    created_at: datetime

    class Config:
        from_attributes = True


class ConversationCreate(BaseModel):
    channel: str = "web_chat"
    customer_email: Optional[str] = None
    customer_name: Optional[str] = None
    initial_message: str


class ConversationResponse(BaseModel):
    id: str
    channel: str
    status: str
    priority: str
    current_intent: Optional[str] = None
    sentiment: Optional[str] = None
    risk_level: str
    confidence: Optional[float] = None
    summary: Optional[str] = None
    customer_id: Optional[str] = None
    assigned_to: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    messages: List[MessageResponse] = []

    class Config:
        from_attributes = True


class ConversationListItem(BaseModel):
    id: str
    channel: str
    status: str
    priority: str
    current_intent: Optional[str] = None
    sentiment: Optional[str] = None
    summary: Optional[str] = None
    customer_name: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
