import secrets
print('SECRET_KEY=' + secrets.token_urlsafe(64))
print('ENCRYPTION_KEY=' + secrets.token_urlsafe(64))
